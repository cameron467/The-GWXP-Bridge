# Literature / Prior-Art Boundary

This file is intentionally short. It lists the principal works used to distinguish established ideas from project-specific constructions.

- Almheiri, Dong & Harlow (2015), *Bulk Locality and Quantum Error Correction in AdS/CFT*, DOI 10.1007/JHEP04(2015)163.
- Pastawski, Yoshida, Harlow & Preskill (2015), *Holographic quantum error-correcting codes*, DOI 10.1007/JHEP06(2015)149.
- Teitelboim (1973), *How commutators of constraints reflect the spacetime structure*, DOI 10.1016/0003-4916(73)90096-1.
- Hojman, Kuchař & Teitelboim (1976), *Geometrodynamics Regained*, DOI 10.1016/0003-4916(76)90112-3.
- Gu & Wen (2012), *Emergence of helicity ±2 modes (gravitons) from qubit models*, DOI 10.1016/j.nuclphysb.2012.05.010.
- Marolf (2015), *Emergent Gravity Requires Kinematic Nonlocality*, DOI 10.1103/PhysRevLett.114.031104.
- Rideout & Sorkin (2000), *Classical sequential growth dynamics for causal sets*, DOI 10.1103/PhysRevD.61.024002.
- Thiemann (2024), *Non-degenerate metrics, hypersurface deformation algebra, non-anomalous representations and density weights in quantum gravity*, DOI 10.1007/s10714-024-03313-w.
- Srivastava & Surya (2026), *Implementing Bell causality in Quantum Sequential Growth*, arXiv:2603.25503.
- Jordan & Farhi (2008), *Perturbative gadgets at arbitrary orders*, DOI 10.1103/PhysRevA.77.062329.

This is not a complete bibliography.
