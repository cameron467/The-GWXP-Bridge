from pathlib import Path
import subprocess, sys, time

root = Path(__file__).resolve().parent
scripts = sorted((root/"scripts").glob("[0-9][0-9]_*.py"))
failed = []
print(f"Running {len(scripts)} GWXP tests...\n")
for s in scripts:
    t0=time.time()
    p=subprocess.run([sys.executable, str(s)], cwd=root, text=True, capture_output=True)
    dt=time.time()-t0
    print("="*80)
    print(s.name, f"({dt:.2f}s)")
    print(p.stdout.rstrip())
    if p.stderr.strip():
        print("STDERR:", p.stderr.rstrip())
    if p.returncode != 0:
        failed.append(s.name)
print("\n"+"="*80)
if failed:
    print("FAIL:", failed)
    raise SystemExit(1)
print("ALL GWXP BUNDLED TESTS PASSED")
