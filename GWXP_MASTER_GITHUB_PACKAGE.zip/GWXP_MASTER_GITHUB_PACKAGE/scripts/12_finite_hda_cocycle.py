import numpy as np
p=5; inv2=pow(2,-1,p); rng=np.random.default_rng(512)
Q=np.array([[1,2,0],[0,1,1],[2,0,1]],dtype=int)%p
def omega(N,M):
    wedge=np.array([N[j,0]*M[j,1]-M[j,0]*N[j,1] for j in range(3)],dtype=int)%p
    return (Q@wedge)%p
def mul(a,b):
    N,g=a; M,h=b
    return ((N+M)%p,(g+h+inv2*omega(N,M))%p)
def inv(a):
    N,g=a; return ((-N)%p,(-g)%p)
def comm(a,b):
    return mul(mul(mul(a,b),inv(a)),inv(b))
def eq(a,b):
    return np.array_equal(a[0],b[0]) and np.array_equal(a[1],b[1])
zN=np.zeros((3,2),dtype=int); zg=np.zeros(3,dtype=int)
for _ in range(10000):
    N=rng.integers(0,p,size=(3,2)); M=rng.integers(0,p,size=(3,2)); L=rng.integers(0,p,size=(3,2))
    g=rng.integers(0,p,size=3); h=rng.integers(0,p,size=3); k=rng.integers(0,p,size=3)
    assert np.array_equal((omega(N,M)+omega((N+M)%p,L))%p,(omega(M,L)+omega(N,(M+L)%p))%p)
    assert eq(mul(mul((N,g),(M,h)),(L,k)),mul((N,g),mul((M,h),(L,k))))
    K=comm((N,zg),(M,zg))
    assert np.array_equal(K[0],zN)
    assert np.array_equal(K[1],omega(N,M))
print("FINITE HDA COCYCLE: PASS")
