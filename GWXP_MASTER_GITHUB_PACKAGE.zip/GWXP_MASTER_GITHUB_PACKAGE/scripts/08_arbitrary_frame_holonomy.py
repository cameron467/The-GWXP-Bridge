import numpy as np

G = np.diag([1.0, np.exp(1j*0.7), np.exp(-1j*1.1)]).astype(complex)
I2 = np.eye(2, dtype=complex)
I3 = np.eye(3, dtype=complex)
X  = np.array([[0,1],[1,0]], dtype=complex)
P0 = np.diag([1,0]).astype(complex)
P1 = np.diag([0,1]).astype(complex)

Ty = np.kron(P0,I3) + np.kron(P1,G)
Wx = np.kron(X,Ty)
Wy = np.kron(I2,np.kron(X,I3))

K = Wx @ Wy @ Wx.conj().T @ Wy.conj().T
Kexpected = np.kron(I2, np.kron(P0,G.conj().T) + np.kron(P1,G))
assert np.linalg.norm(K-Kexpected) < 1e-12

I12 = np.eye(12,dtype=complex)
H = (2*I12-Wx-Wx.conj().T) + (2*I12-Wy-Wy.conj().T)
evals,evecs = np.linalg.eigh(H)
mask = evals < 1e-10
Pground = evecs[:,mask] @ evecs[:,mask].conj().T

assert np.linalg.norm((Wx-I12)@Pground) < 1e-10
assert np.linalg.norm((Wy-I12)@Pground) < 1e-10

print("diamond residual:", np.linalg.norm(K-Kexpected))
print("ground dimension:", mask.sum())
print("gap:", evals[evals>1e-10][0])
