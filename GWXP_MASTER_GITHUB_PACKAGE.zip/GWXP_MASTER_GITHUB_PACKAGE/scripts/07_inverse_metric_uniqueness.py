import numpy as np
import itertools

eps = np.zeros((3,3,3), dtype=int)
eps[0,1,2] = eps[1,2,0] = eps[2,0,1] = 1
eps[0,2,1] = eps[2,1,0] = eps[1,0,2] = -1

def cofactor_frame(E):
    C = np.zeros((3,3), dtype=float)
    for i,a in itertools.product(range(3), repeat=2):
        for j,k,b,c in itertools.product(range(3), repeat=4):
            C[i,a] += 0.5*eps[i,j,k]*eps[a,b,c]*E[j,b]*E[k,c]
    return C

def quartic_pairing(E, pairing):
    T = np.zeros((3,3), dtype=float)
    for i,j in itertools.product(range(3), repeat=2):
        for k,l,m,n,a,b,c,d in itertools.product(range(3), repeat=8):
            if eps[i,k,l] == 0 or eps[j,m,n] == 0:
                continue
            if pairing == 0:
                inv = (a==b) and (c==d)
            elif pairing == 1:
                inv = (a==c) and (b==d)
            else:
                inv = (a==d) and (b==c)
            if inv:
                T[i,j] += eps[i,k,l]*eps[j,m,n]*E[k,a]*E[l,b]*E[m,c]*E[n,d]
    return T

rng = np.random.default_rng(560)
for sample in range(3):
    while True:
        E = rng.normal(size=(3,3))
        if abs(np.linalg.det(E)) > 0.2:
            break
    q = E @ E.T
    C = cofactor_frame(E)
    M = C @ C.T
    T0,T1,T2 = [quartic_pairing(E,p) for p in range(3)]
    adjq = np.linalg.det(q)*np.linalg.inv(q)

    assert np.linalg.norm(T0) < 1e-10
    assert np.linalg.norm(T1-2*M) < 1e-10
    assert np.linalg.norm(T2+2*M) < 1e-10
    assert np.linalg.norm(M-adjq) < 1e-10

    print(sample+1,
          np.linalg.norm(T0),
          np.linalg.norm(T1-2*M),
          np.linalg.norm(T2+2*M),
          np.linalg.norm(M-adjq))
