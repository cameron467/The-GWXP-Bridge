import numpy as np
Delta_s=2-np.sqrt(2)
masses=np.array([Delta_s,1.15,1.35,1.70])
M2=np.diag(masses**2)
B=np.array([[0.08,0.10,-0.06,0.04],[-0.05,0.07,0.09,0.03]])
stiff=np.eye(2)-B@np.linalg.inv(M2)@B.T
e=np.linalg.eigvalsh(stiff)
assert np.min(e)>0
rho=np.linalg.norm(B@np.linalg.inv(np.diag(masses)),2)**2
assert rho<1
def Hk(k):
    return np.block([[k*k*np.eye(2),k*B],[k*B.T,M2]])
ks=np.logspace(-5,-1,17)
for k in ks:
    ev=np.linalg.eigvalsh(Hk(k))
    assert ev[2] > 0.25
soft=np.linalg.eigvalsh(Hk(1e-5))[:2]/1e-10
assert np.allclose(soft,e,rtol=2e-4,atol=2e-4)
print("TT + SCHEDULE COEXISTENCE: PASS")
print("schedule gap:",Delta_s)
print("TT stiffness eigenvalues:",e)
print("||B M^-1||^2:",rho)
