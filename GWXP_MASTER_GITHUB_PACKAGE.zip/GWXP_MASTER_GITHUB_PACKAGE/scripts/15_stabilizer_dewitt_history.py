import numpy as np
P=5; NS=3; NC=6; NV=NS*NC
def rank_mod(A,p=P):
    A=np.array(A,dtype=int)%p; m,n=A.shape; r=0
    for c in range(n):
        pivot=next((i for i in range(r,m) if A[i,c]%p),None)
        if pivot is None: continue
        A[[r,pivot]]=A[[pivot,r]]
        A[r]=(A[r]*pow(int(A[r,c]),-1,p))%p
        for i in range(m):
            if i!=r and A[i,c]:
                A[i]=(A[i]-A[i,c]*A[r])%p
        r+=1
        if r==m: break
    return r
D=np.array([[-1,1,0],[0,-1,1],[1,0,-1]],dtype=int)%P
L=(D.T@D)%P
M=np.zeros((3*NS,NV),dtype=int)
for block,comp in enumerate([0,3,4]):
    M[block*NS:(block+1)*NS,comp*NS:(comp+1)*NS]=D
S0=np.zeros((NS,NV),dtype=int)
S0[:,NS:2*NS]=L; S0[:,2*NS:3*NS]=L
C=np.zeros((NS+3*NS,2*NV),dtype=int)
C[:NS,:NV]=S0; C[NS:,NV:]=M
J=np.block([[np.zeros((NV,NV),dtype=int),np.eye(NV,dtype=int)],[-np.eye(NV,dtype=int),np.zeros((NV,NV),dtype=int)]])%P
assert np.all((C@J@C.T)%P==0)
rank_C=rank_mod(C)
def shear(lam):
    G=np.eye(NC,dtype=int)
    G[:3,:3]=(np.eye(3,dtype=int)-lam*np.ones((3,3),dtype=int))%P
    K=np.zeros((NV,NV),dtype=int)
    for a in range(NC):
        for b in range(NC):
            for x in range(NS):
                K[a*NS+x,b*NS+x]=G[a,b]
    I=np.eye(NV,dtype=int)
    return np.block([[I,K],[np.zeros_like(I),I]])%P
surv=[]
for lam in range(P):
    aug=rank_mod(np.vstack([C,(C@shear(lam))%P]))
    if aug==rank_C: surv.append(lam)
assert surv==[3] and (2*3)%P==1
print("STABILIZER DEWITT HISTORY: PASS")
print("stabilizer rank:",rank_C,"unique lambda:",surv[0],"=1/2 mod 5")
