import numpy as np
p=5
rng=np.random.default_rng(511)
def inv_mod(A,p):
    A=np.array(A,dtype=int)%p; n=A.shape[0]
    aug=np.concatenate([A,np.eye(n,dtype=int)],axis=1)%p
    r=0
    for c in range(n):
        pivot=next(i for i in range(r,n) if aug[i,c]%p)
        aug[[r,pivot]]=aug[[pivot,r]]
        aug[r]=(aug[r]*pow(int(aug[r,c]),-1,p))%p
        for i in range(n):
            if i!=r and aug[i,c]:
                aug[i]=(aug[i]-aug[i,c]*aug[r])%p
        r+=1
    return aug[:,n:]%p
def rand_GL():
    while True:
        A=rng.integers(0,p,size=(3,3))
        try: inv_mod(A,p); return A%p
        except: pass
def rand_sym_inv():
    while True:
        R=rng.integers(0,p,size=(3,3)); Q=(R+R.T)%p
        try: inv_mod(Q,p); return Q
        except: pass

for _ in range(1000):
    A=rand_GL(); Q=rand_sym_inv()
    alpha=rng.integers(0,p,size=3); g=rng.integers(0,p,size=3)
    Ainv=inv_mod(A,p)
    Qp=(A@Q@A.T)%p
    alphap=(Ainv.T@alpha)%p
    left=(A@((g+Q@alpha)%p))%p
    right=((A@g)%p + Qp@alphap)%p
    assert np.array_equal(left%p,right%p)
print("FINITE SPATIAL COVARIANCE: PASS")
