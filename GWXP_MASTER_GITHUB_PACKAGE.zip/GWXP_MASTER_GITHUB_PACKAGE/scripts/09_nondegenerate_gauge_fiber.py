import itertools, numpy as np
from collections import Counter

p=3
def rank_mod_p(A,p):
    A=np.array(A,dtype=int)%p
    m,n=A.shape; r=0; col=0
    while r<m and col<n:
        pivot=next((i for i in range(r,m) if A[i,col]%p),None)
        if pivot is None:
            col+=1; continue
        A[[r,pivot]]=A[[pivot,r]]
        A[r]=(A[r]*pow(int(A[r,col]),-1,p))%p
        for i in range(m):
            if i!=r and A[i,col]:
                A[i]=(A[i]-A[i,col]*A[r])%p
        r+=1; col+=1
    return r

counts=Counter()
for entries in itertools.product(range(p),repeat=9):
    Q=np.array(entries,dtype=int).reshape(3,3)
    r=rank_mod_p(Q,p)
    counts[(r,p**(3-r))]+=1

assert counts[(3,1)]==(27-1)*(27-3)*(27-9)
assert counts[(2,3)]==8112
assert counts[(1,9)]==338
assert counts[(0,27)]==1
print("NONDEGENERATE GAUGE FIBER: PASS")
for k,v in sorted(counts.items()):
    print(k,v)
