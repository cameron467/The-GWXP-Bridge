import numpy as np

def spin1():
    Sz=np.diag([1,0,-1]).astype(complex)
    Sp=np.zeros((3,3),complex)
    Sp[0,1]=np.sqrt(2); Sp[1,2]=np.sqrt(2)
    Sm=Sp.conj().T
    return (Sp+Sm)/2,(Sp-Sm)/(2j),Sz

Sx,Sy,Sz=spin1()
I3=np.eye(3,dtype=complex)
Q=np.kron(Sx,Sx)+np.kron(Sy,Sy)+np.kron(Sz,Sz)
n=np.diag([0,1]).astype(complex)
X=np.array([[0,1],[1,0]],complex)
I2=np.eye(2,dtype=complex)
I9=np.eye(9,dtype=complex)

e=np.eye(3,dtype=complex)
A01=np.outer(e[1],e[0])+np.outer(e[0],e[1])
A12=np.outer(e[2],e[1])+np.outer(e[1],e[2])
A20=np.outer(e[0],e[2])+np.outer(e[2],e[0])
P0=np.outer(e[0],e[0])

def k4(a,b,c,d): return np.kron(np.kron(np.kron(a,b),c),d)
V1=k4(Q,I2,I2,A01)
V2=k4(I9,n,I2,A12)
V3=k4(I9,I2,X,A20)
V=V1+V2+V3
P=k4(I9,I2,I2,P0)
Qfull=np.eye(P.shape[0],dtype=complex)-P
R=-Qfull

H2=P@V@R@V@P
H3=P@V@R@V@R@V@P
target2=-k4(Q@Q,I2,I2,P0)-k4(I9,I2,I2,P0)
target3=2*k4(Q,n,X,P0)

e2=np.linalg.norm(H2-target2)
e3=np.linalg.norm(H3-target3)
assert e2<1e-10 and e3<1e-10
print("STATIC MEDIATOR: PASS")
print("second-order residual:",e2)
print("third-order residual:",e3)
print("H_eff^(3) = 2 g1 g2 g3 / Delta^2 * Q n_c X_g")
