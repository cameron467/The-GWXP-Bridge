import itertools, numpy as np
p=5
Q=np.array([1,2,4],dtype=int)%p

# Affine coordinates z=(c0,c1,g0,g1,g2,1).
# A(n): c0->c0+n, g->g+Q*n*c1
# B(m): c1->c1+m

def A(n):
    M=np.eye(6,dtype=int)
    M[0,5]=n%p
    for i in range(3):
        M[2+i,1]=(Q[i]*n)%p
    return M%p

def B(m):
    M=np.eye(6,dtype=int)
    M[1,5]=m%p
    return M%p

def W(N):
    return (A(N[0])@B(N[1]))%p

def inv_aff(M):
    # Generic Gauss-Jordan inverse over Z_p.
    n=M.shape[0]
    aug=np.concatenate([M%p,np.eye(n,dtype=int)],axis=1)%p
    r=0
    for c in range(n):
        pivot=next(i for i in range(r,n) if aug[i,c]%p)
        aug[[r,pivot]]=aug[[pivot,r]]
        aug[r]=(aug[r]*pow(int(aug[r,c]),-1,p))%p
        for i in range(n):
            if i!=r and aug[i,c]:
                aug[i]=(aug[i]-aug[i,c]*aug[r])%p
        r+=1
    return aug[:,n:]%p

def expected(N,M):
    wedge=(N[0]*M[1]-M[0]*N[1])%p
    E=np.eye(6,dtype=int)
    for i in range(3):
        E[2+i,5]=(Q[i]*wedge)%p
    return E%p

lapses=list(itertools.product(range(p),repeat=2))
for N in lapses:
    WN=W(N); WNi=inv_aff(WN)
    for M in lapses:
        WM=W(M); WMi=inv_aff(WM)
        K=(WN@WM@WNi@WMi)%p
        assert np.array_equal(K,expected(N,M))

print('EXACT LAPSE WEDGE: PASS')
print('all ordered lapse pairs checked:',len(lapses)**2)
print('identity is affine-operator exact, hence independent of basis state')
