import numpy as np

P=5; NS=3; NC=6; NV=NS*NC

def rank_mod(A,p=P):
    A=np.array(A,dtype=int)%p
    m,n=A.shape; r=0
    for c in range(n):
        pivot=next((i for i in range(r,m) if A[i,c]%p),None)
        if pivot is None: continue
        A[[r,pivot]]=A[[pivot,r]]
        A[r]=(A[r]*pow(int(A[r,c]),-1,p))%p
        for i in range(m):
            if i!=r and A[i,c]:
                A[i]=(A[i]-A[i,c]*A[r])%p
        r+=1
        if r==m: break
    return r

D=np.array([[-1,1,0],[0,-1,1],[1,0,-1]],dtype=int)%P
L=(D.T@D)%P

M=np.zeros((3*NS,NV),dtype=int)
for block,comp in enumerate([0,3,4]):
    M[block*NS:(block+1)*NS,comp*NS:(comp+1)*NS]=D
rank_M=rank_mod(M)

def G_lambda(lam):
    G=np.eye(NC,dtype=int)
    G[:3,:3]=(np.eye(3,dtype=int)-lam*np.ones((3,3),dtype=int))%P
    return G%P

def symplectic_residual(lam):
    G=G_lambda(lam)
    K=np.zeros((NV,NV),dtype=int)
    for a in range(NC):
        for b in range(NC):
            for x in range(NS):
                K[a*NS+x,b*NS+x]=G[a,b]
    I=np.eye(NV,dtype=int)
    S=np.block([[I,K],[np.zeros_like(I),I]])%P
    J=np.block([[np.zeros_like(I),I],[-I,np.zeros_like(I)]])%P
    return np.max(np.abs((S.T@J@S-J)%P))

survivors=[]
for lam in range(P):
    A=np.zeros((NS,NV),dtype=int)
    A[:,0*NS:1*NS]=(-2*lam*L)%P
    A[:,1*NS:2*NS]=((1-2*lam)*L)%P
    A[:,2*NS:3*NS]=((1-2*lam)*L)%P
    rank_aug=rank_mod(np.vstack([M,A]))
    keep=(rank_aug==rank_M)
    print(lam,rank_aug,keep,symplectic_residual(lam)==0)
    if keep: survivors.append(lam)

assert survivors==[3]
assert (2*3)%5==1
print("unique survivor: lambda=3=1/2 mod 5")
