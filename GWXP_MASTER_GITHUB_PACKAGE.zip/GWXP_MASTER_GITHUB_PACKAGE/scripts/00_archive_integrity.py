from pathlib import Path
import csv, json, math

ROOT = Path(__file__).resolve().parents[1]
with open(ROOT/"data/K4_K8_SCALING.csv", newline="") as f:
    rows = list(csv.DictReader(f))
vals = {int(r["N"]): float(r["sigma_soft"]) for r in rows}
expected = {
    4: 0.2500221817742957,
    5: 0.2500067914741485,
    6: 0.1890521106210234,
    7: 0.1666732809348302,
    8: 0.1389102561821202,
}
assert vals.keys() == expected.keys()
for n, v in expected.items():
    assert math.isclose(vals[n], v, rel_tol=0, abs_tol=1e-14)

with open(ROOT/"data/BOUNDARY_VERDICT.json") as f:
    b = json.load(f)
for n in [4,5,6,7]:
    assert math.isclose(float(b["raw_sigma_soft"][str(n)]), expected[n], rel_tol=0, abs_tol=1e-14)
assert abs(float(b["validated_interpretation"]["k7_detuning_exponent"]) + 1) < 1e-5

with open(ROOT/"data/v4_mots_bridge_manifest.json") as f:
    m = json.load(f)
assert abs(float(m["headline_results"]["fold_alpha"]) - 0.5) < 1e-4
assert "compatibility/existence toy" in m["scientific_scope"]

print("ARCHIVE INTEGRITY: PASS")
print("K4-K8 sigma_soft:", vals)
print("K7 exponent:", b["validated_interpretation"]["k7_detuning_exponent"])
print("V4 MOTS compatibility-toy fold alpha:", m["headline_results"]["fold_alpha"])
print("CAUTION: the later V4 normalization audit supersedes any old claim that this is clean same-coupling finite-size scaling.")
