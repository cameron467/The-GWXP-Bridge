import numpy as np
import itertools

def idx(q, x, y, g):
    return (((q*2 + x)*2 + y)*2 + g)

dim = 16
I = np.eye(dim)
Wy = np.zeros((dim, dim))
Wx = np.zeros((dim, dim))
G = np.zeros((dim, dim))

for q, x, y, g in itertools.product(range(2), repeat=4):
    Wy[idx(q,x,y^1,g), idx(q,x,y,g)] = 1
    Wx[idx(q,x^1,y,g^(q & y)), idx(q,x,y,g)] = 1
    G[idx(q,x,y,g^q), idx(q,x,y,g)] = 1

assert np.linalg.norm(Wx @ Wy @ Wx @ Wy - G) < 1e-12

Jx = Jy = 1.0
H = Jx*(I-Wx) + Jy*(I-Wy)
evals, evecs = np.linalg.eigh(H)
zero = evals < 1e-10
P0 = evecs[:,zero] @ evecs[:,zero].conj().T
gap = evals[np.where(evals > 1e-10)[0][0]]

print("diamond residual:", np.linalg.norm(Wx @ Wy @ Wx @ Wy - G))
print("ground dimension:", zero.sum())
print("gap:", gap)
print("gauge residual on ground:", np.linalg.norm((G-I) @ P0))

assert np.linalg.norm((Wx-I) @ P0) < 1e-10
assert np.linalg.norm((Wy-I) @ P0) < 1e-10
assert np.linalg.norm((G-I) @ P0) < 1e-10
assert abs(gap-(2-np.sqrt(2))) < 1e-10

for Jx,Jy in [(1,2),(0.5,3),(2,2),(0.1,1)]:
    H2 = Jx*(I-Wx) + Jy*(I-Wy)
    ev = np.linalg.eigvalsh(H2)
    num_gap = ev[np.where(ev > 1e-10)[0][0]]
    formula = Jx + Jy - np.sqrt(Jx**2 + Jy**2)
    assert abs(num_gap-formula) < 1e-10
    print(Jx, Jy, num_gap, formula)
