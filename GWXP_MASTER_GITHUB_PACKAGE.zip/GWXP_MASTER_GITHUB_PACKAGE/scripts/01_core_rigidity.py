import sympy as sp

# Fierz-Pauli / linearized Einstein spatial rigidity
a,b,c,d,e = sp.symbols("a b c d e")
sol = sp.linsolve([
    a+b,
    b+d,
    c+e,
    c-d,
], (a,b,c,d,e))
print("FP solution family:", sol)
# parameterization implies a=-b, d=-b, c=d=-b, e=-c=b
t = sp.symbols("t")
vec = (-t, t, -t, -t, t)
assert all(sp.expand(x) == 0 for x in [
    vec[0]+vec[1], vec[1]+vec[3], vec[2]+vec[4], vec[2]-vec[3]
])

# DeWitt trace ratio
alpha,beta = sp.symbols("alpha beta")
dewitt = sp.solve(sp.Eq(alpha + 2*beta, 0), beta)[0]
assert dewitt == -alpha/2

# TEGR ray from unwanted frame modes
c1,c2,c3 = sp.symbols("c1 c2 c3")
tegr = sp.solve([
    sp.Eq(2*c1+c2+c3,0),
    sp.Eq(2*c1-c2,0)
], (c2,c3), dict=True)[0]
assert sp.simplify(tegr[c2] - 2*c1) == 0
assert sp.simplify(tegr[c3] + 4*c1) == 0

assert 6-3-1 == 2
print("CORE RIGIDITY: PASS")
print("DeWitt beta/alpha =", sp.simplify(dewitt/alpha))
print("TEGR ray =", "(1,2,-4)")
print("finite symmetric-tensor count = 6-3-1 = 2")
