# The GWXP Bridge — Research Evidence Package

This repository package preserves the full research path from the original **Cosmic Glue** premise through the V5 finite-refoliation work.

## Start here

**[MASTER_EVIDENCE_LEDGER.md](MASTER_EVIDENCE_LEDGER.md)** is the authoritative claim/evidence/falsification map.

It includes:

- the opening assumptions and why they failed;
- the finite-causal/QEC pivot;
- spin-2 constraint counting;
- commuting-projector failure;
- Fierz–Pauli / DeWitt / TEGR rigidity;
- Newton-coupling and capacity tests;
- entropy and black-hole boundary tests;
- the V4 SU(2) numerical branch and its later normalization correction;
- moving-code Love response and MOTS/fold work;
- the full V5 finite schedule/refoliation construction;
- exact finite DeWitt selection;
- the final unresolved natural-emergence theorem.

## Reproduce the bundled tests

```bash
python -m pip install -r requirements.txt
python run_all_tests.py
```

The tests are **structure/existence/rigidity checks**, not a simulation proving GR emerges from a generic Hamiltonian.

## Current status

**Not proved:** one simple autonomous finite Hamiltonian naturally realizes the complete gravitational constraint/refoliation + two-TT phase.

**Substantially developed:** the mathematical-existence / conditional-mechanism architecture and a falsification ledger for the remaining phase-emergence problem.

See the master ledger before quoting any result.
