# GWXP V5.10 — Exact Finite Lapse-Wedge Algebra

Consider one oriented spatial edge \(x\to y=x+\hat e_j\), a finite schedule variable at each endpoint, and a three-component spatial gauge register \(g_i\in\mathbb Z_p^3\).

Let \(Q^{ij}\) be the finite inverse-frame column associated with edge direction \(j\). Define two finite local update families

\[
A_x(n):
\quad
c_x\mapsto c_x+n,\qquad
g_i\mapsto g_i+Q^{ij}n\,c_y,
\]

\[
B_y(m):
\quad
c_y\mapsto c_y+m.
\]

They form a finite class-2 nilpotent/Heisenberg-type algebra. Their commutator is central in the gauge register:

\[
A_x(n)B_y(m)A_x(-n)B_y(-m):
\quad
g_i\mapsto g_i+Q^{ij}nm.
\]

Define the edge contribution to a smeared normal move by

\[
W(N)=A_x(N_x)B_y(N_y).
\]

Then exactly,

\[
\boxed{
W(N)W(M)W(N)^{-1}W(M)^{-1}:
g_i\mapsto
g_i+
Q^{ij}
\left(
N_xM_y-M_xN_y
\right).
}
\]

This is already the discrete antisymmetric lapse wedge.

For a lattice spacing \(a\),

\[
M_y=M_x+a\,\partial_jM+O(a^2),
\qquad
N_y=N_x+a\,\partial_jN+O(a^2),
\]

so

\[
N_xM_y-M_xN_y
=
a\left(
N\partial_jM-M\partial_jN
\right)
+O(a^2).
\]

Therefore the finite group law has the continuum limit

\[
\boxed{
\xi^i
=
q^{ij}
\left(
N\partial_jM-M\partial_jN
\right),
}
\]

provided the finite relational frame variable \(Q^{ij}\) converges to the inverse metric \(q^{ij}\).

The identity was exhaustively checked for \(p=5\), all \(5^5=3125\) basis states, and all \(25^2=625\) ordered pairs of edge lapse vectors for a nontrivial three-component \(Q\).

## Status

**DERIVED / exact finite algebra:** the antisymmetric lapse-gradient structure of the HDA can arise directly from a finite local group commutator; it need not be inserted as a continuum formula.

**DERIVED / previous V5 steps:** the frame-dependent coefficient can be supplied by a relational finite frame and, at lowest background-free order, is forced into the inverse-metric tensor slot.

**OPEN:** assemble these edge algebras consistently on a full 3D lattice with shared frame variables and demonstrate closure of all overlapping diamonds/Jacobi relations in one local Hamiltonian.
