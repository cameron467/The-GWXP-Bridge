# GWXP / Cosmic Glue — V5 Final Research Verdict
27 September 2026

## Bottom line

The full natural-emergence GWXP hypothesis is **not proved**.

The project has, however, essentially completed the **mathematical-existence / conditional-mechanism** program: finite quantum systems can realize the required tensor/frame carriers, moving protected subspaces, exact finite schedule/refoliation holonomies, frame-dependent HDA-like structure functions, finite canonical frame-momentum dynamics, DeWitt rigidity, two-TT coexistence, and the previously derived TEGR/Fierz-Pauli/black-hole response structures.

The remaining gap is no longer an algebraic obstruction. It is a **phase-emergence problem**:

> Does one simple autonomous finite local Hamiltonian enter a stable low-energy phase in which the gravitational constraint code itself appears, rather than being inserted through specially chosen stabilizers or propagation rules?

Writing a parent Hamiltonian whose ground space is explicitly the desired scalar+momentum stabilizer code would not answer this question; it would compile the gravitational constraint structure into the microscopic model.

## What V5 added

### Exact finite refoliation carrier
Finite schedule/update operators can have a frame-dependent group commutator that closes into spatial gauge.

### Autonomous zero-frustration mechanism
A positive schedule-hopping Hamiltonian can make spatial gauge invariance follow from simultaneous zero frustration, without a separate gauge projector.

### Relational frame structure function
Rotationally invariant spin-frame observables can control the finite holonomy. The same frame supplies metric and densitized inverse-frame data.

### Background-free inverse metric
At the lowest parity-even polynomial order, the unique nonzero background-free contravariant rank-two tensor from the relational frame is

\[
C^i{}_aC^j{}_a=\det(q)\,q^{ij},
\]

up to normalization and higher-derivative corrections.

### Exact finite lapse wedge
A finite local group commutator realizes

\[
\xi^i_{\rm finite}
=
Q^{ij}(N_xM_y-M_xN_y),
\]

whose continuum limit is

\[
\xi^i=q^{ij}(N\partial_jM-M\partial_jN).
\]

### Associative finite HDA cocycle
The finite normal-normal law can be represented as an exact group 2-cocycle, not merely a specially chosen circuit identity.

### Nondegenerate geometry
For finite \(Q\in{\rm Mat}_{3\times3}(\mathbb Z_p)\),

\[
\dim{\cal H}_{\rm gauge\ fixed}=p^{3-\operatorname{rank}Q}.
\]

Thus nondegenerate \(Q\) gives a constant one-dimensional gauge fiber, while degenerate frames enlarge the protected fiber.

### Finite canonical frame momentum
Discrete Weyl/Clifford phase space provides exact finite conjugate frame dynamics without requiring an impossible finite-dimensional canonical commutator.

### Exact finite DeWitt selection
On the three-site \(\mathbb Z_5\) regulator, preserving the gravitational constraint ideal under the most general DeWitt-family finite canonical shear uniquely selects

\[
\lambda=\frac12.
\]

The same result holds at the finite stabilizer-code level: only the DeWitt Clifford shear preserves the protected gravitational code.

### TT/refoliation coexistence
A gapped schedule/refoliation sector can coexist with exactly two soft linearly dispersing tensor modes throughout an open coupling region.

## What is now killed

- Bare causal-diamond consistency alone selects GR coefficients.
- A fixed commutative lattice is sufficient for the normal-normal HDA.
- The HHH Jacobi identity by itself selects the DeWitt supermetric.
- The finite structure function must be supplied by an independent inverse-metric register.
- The schedule/refoliation sector necessarily reintroduces a low physical scalar.
- Exact finite dimensionality prevents state-dependent refoliation closure.
- A hand-built scalar+momentum stabilizer parent Hamiltonian would constitute natural emergence.

## Final status

### Essentially complete
**Mathematical-existence GWXP:** finite quantum degrees can support the architecture needed for GR-like geometry, including a finite refoliation carrier and compatible two-TT sector.

### Strong conditional result
If one autonomous finite frame phase generates the local schedule/constraint code, then locality, background independence, path independence and constraint preservation rigidly drive its low-energy dynamics toward the GR/TEGR structures already derived in the project.

### Still open
**Natural-emergence GWXP:** show that the constraint code itself is a stable phase of one simple autonomous microscopic Hamiltonian without explicitly programming the gravitational constraints into it.

This is now a condensed-matter / phase-diagram problem rather than another missing algebra identity.

## Honest final sentence

GWXP has **not derived gravity from finite information**, but it has reduced that claim to one sharply falsifiable remaining question:

\[
\boxed{
\text{Can a simple finite relational frame Hamiltonian spontaneously realize the gravitational constraint/refoliation phase?}
}
\]

Everything downstream is now sufficiently constrained that another hand-designed toy model would add little. The next meaningful work would be a genuine phase search over a small symmetry-allowed Hamiltonian family.
