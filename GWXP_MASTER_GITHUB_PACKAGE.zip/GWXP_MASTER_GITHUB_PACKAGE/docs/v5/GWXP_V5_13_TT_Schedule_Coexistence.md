# GWXP V5.13 — Open-Region Coexistence of TT and Schedule Sectors

Take the exact finite schedule/refoliation sector from V5.6. For \(J_x=J_y=1\) its nonzero gap is

\[
\Delta_s=2-\sqrt2.
\]

Let the low-energy frame sector contain two soft TT coordinates \(h_A\), \(A=1,2\), while the schedule/scalar, vector, antisymmetric and other non-geometric modes are collected into a gapped vector \(X\).

The most general leading derivative mixing has quadratic Hessian

\[
{\cal H}(k)=
\begin{pmatrix}
c^2k^2I_2 & kB\\
kB^\dagger & M^2+O(k^2)
\end{pmatrix},
\]

where \(M^2>0\) contains \(\Delta_s^2\) and the other defect gaps.

Integrating out the gapped modes gives

\[
{\cal H}_{\rm eff}^{TT}
=
k^2\left[
c^2I_2-BM^{-2}B^\dagger
\right]
+O(k^4).
\]

Therefore a sufficient condition for two healthy linearly dispersing tensor modes is

\[
\boxed{
\|BM^{-1}\|_2^2<c^2.
}
\]

This is a strict inequality and hence defines an **open region**, not a tuned surface.

A deterministic six-mode numerical example using the exact schedule gap \(\Delta_s=2-\sqrt2\) gives two eigenvalues proportional to \(k^2\), with coefficients matching the Schur complement, while all four unwanted modes remain gapped across the small-\(k\) scan.

## Consequence

The finite schedule/refoliation sector does not generically force an extra low scalar back into the spectrum. Once its nonphysical modes are gapped, symmetry-allowed derivative mixing with a two-TT phase preserves exactly two soft \(z=1\) modes throughout an open coupling region.

This closes the *coexistence obstruction* at quadratic order.

## Still open

This is not yet the microscopic natural-emergence theorem. It assumes the frame Hamiltonian has entered the two-TT phase and the schedule Hamiltonian has entered its zero-frustration phase. The remaining task is to exhibit one simple local finite Hamiltonian whose phase diagram contains both simultaneously without separately tuning each sector to the desired continuum theory.
