# GWXP V5.7 — Symmetry-Forced Inverse-Metric Coupling

Let \(E_i{}^a\) be the relational coframe. We seek a local, derivative-free, parity-even object \(M^{ij}(E)\) that:

1. is invariant under the internal \(SO(3)\);
2. has two contravariant spatial indices;
3. uses no background spatial metric;
4. is polynomial and of lowest possible degree.

One upper spatial index must be made with a spatial Levi-Civita density and therefore requires two coframes:

\[
C^i{}_a
=
\frac12\epsilon^{ikl}\epsilon_{abc}E_k{}^bE_l{}^c.
\]

Two upper spatial indices therefore first occur at fourth order. The most general internal \(SO(3)\)-invariant contraction of four vector indices is spanned by

\[
\delta_{ab}\delta_{cd},\qquad
\delta_{ac}\delta_{bd},\qquad
\delta_{ad}\delta_{bc}.
\]

When inserted between the two spatial epsilon tensors:

- the first contraction vanishes because an epsilon hits a symmetric Gram tensor;
- the second and third are equal up to sign.

Hence the surviving space is one-dimensional:

\[
M^{ij}\propto C^i{}_aC^j{}_a.
\]

For nondegenerate \(E\),

\[
C^i{}_aC^j{}_a
=
\det(q)\,q^{ij},
\qquad
q_{ij}=E_i{}^aE_j{}^a.
\]

Because \(C^i{}_aC^j{}_a\) has density weight \(+2\), while the HDA structure function must have weight zero, dividing by \(\det q\) fixes

\[
M^{ij}_{\rm weight\,0}\propto q^{ij}.
\]

Thus, once a nondegenerate relational frame is the only local geometric field, the inverse metric is the unique lowest-order background-free parity-even tensor that can map the lapse-gradient covector into the spatial shift vector. The remaining freedom is an overall normalization (and higher-derivative corrections).

This is a differential-geometric rigidity statement, not a claim of novel mathematics. The project-specific use is that the HDA structure function no longer has to be independently inserted once the frame exists.
