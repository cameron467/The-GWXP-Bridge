# GWXP V5.11 — Finite Spatial-Covariance / Mixed-Closure Test

Let

\[
Q\in GL(3,\mathbb Z_p)
\]

be a symmetric finite inverse-frame tensor, let \(\alpha_j\) be a finite lapse-gradient covector, and let \(g^i\) be a spatial-gauge vector.

Define the HDA-like gauge displacement

\[
G_Q(\alpha):
\qquad
g\mapsto g+Q\alpha.
\]

Under a finite spatial basis transformation

\[
A\in GL(3,\mathbb Z_p),
\]

transform

\[
Q\mapsto AQA^T,
\qquad
\alpha\mapsto A^{-T}\alpha,
\qquad
g\mapsto Ag.
\]

Then exactly,

\[
\boxed{
S_A\,G_Q(\alpha)\,S_A^{-1}
=
G_{AQA^T}(A^{-T}\alpha).
}
\]

Thus the finite schedule-holonomy map is covariant under spatial frame changes with precisely the tensor law needed for a contravariant two-tensor mapping a covector into a vector.

This addresses the mixed spatial/normal consistency that the single-edge toy did not test: the frame-dependent structure function is not treated as a central scalar under spatial gauge transformations.

Because these transformations are literal finite permutations forming a semidirect product, their group multiplication is associative and the corresponding group commutator identities are exact.

## What this does not yet do

It does **not** specify the change of \(Q\) under a normal move. In canonical GR that change is dynamical and depends on the momentum/extrinsic-curvature sector. Therefore the remaining nonlinear closure problem is now localized to:

\[
\boxed{\text{normal update of the frame }Q\text{ versus its conjugate momentum}.}
\]

The earlier DeWitt-rigidity calculation is precisely the continuum condition on that missing update.
