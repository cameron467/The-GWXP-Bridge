# GWXP V5.12 — Exact Finite HDA Cocycle Group

Fix a nondegenerate finite frame \(Q^{ij}\in GL(3,\mathbb Z_p)\), with \(p\) odd.

For each spatial direction \(j\), let a discrete lapse field \(N\) have two values on an oriented edge,

\[
(N_{j,0},N_{j,1}).
\]

Define the alternating bilinear map

\[
\omega_Q^i(N,M)
=
\sum_j
Q^{ij}
\left(
N_{j,0}M_{j,1}
-
M_{j,0}N_{j,1}
\right).
\]

Because \(\omega_Q\) is bilinear,

\[
\omega(N,M)+\omega(N+M,L)
=
\omega(M,L)+\omega(N,M+L).
\]

Thus \(\tfrac12\omega_Q\) is an exact group 2-cocycle over \(\mathbb Z_p\).

Define the finite group law

\[
(N,g)\star(M,h)
=
\left(
N+M,\;
g+h+\frac12\omega_Q(N,M)
\right).
\]

The cocycle identity guarantees exact associativity. The inverse is

\[
(N,g)^{-1}=(-N,-g),
\]

and the exact group commutator is

\[
\boxed{
[(N,0),(M,0)]_{\rm group}
=
(0,\omega_Q(N,M)).
}
\]

Therefore

\[
\boxed{
\xi^i_{\rm finite}
=
\sum_jQ^{ij}
\left(
N_{j,0}M_{j,1}-M_{j,0}N_{j,1}
\right)
}
\]

is not merely the result of one specially chosen circuit: it is the central extension law of a bona-fide finite group.

For edge spacing \(a\),

\[
N_{j,0}M_{j,1}-M_{j,0}N_{j,1}
=
a(N\partial_jM-M\partial_jN)+O(a^2),
\]

so the continuum contraction tends to the normal-normal HDA structure

\[
\xi^i
=
q^{ij}(N\partial_jM-M\partial_jN)
\]

when \(Q^{ij}\to q^{ij}\).

Combined with V5.11, spatial frame transformations act covariantly on the cocycle, so the fixed-frame finite HDA group can be extended by spatial frame changes as a semidirect product.

## Status

**DERIVED / exact finite kinematic existence:** the normal-normal deformation law, including the antisymmetric lapse wedge and a frame-dependent inverse-metric map, admits an associative finite group realization.

**IMPORTANT LIMITATION:** \(Q\) is fixed during the normal group multiplication. The genuinely nonlinear gravitational problem is to make \(Q\) itself a dynamical frame variable under normal evolution while preserving the same algebra in the protected low-energy sector.

That remaining problem is precisely the frame-momentum / DeWitt dynamics problem, not the existence of a finite refoliation algebra.
