# GWXP V5.6 — Autonomous Schedule-Holonomy Verdict

## Exact finite model

Use four qubits \((q,x,y,g)\):

- \(q\): finite frame/geometry bit,
- \(x,y\): two local schedule/update bits,
- \(g\): spatial-label gauge bit.

Define

\[
W_y:\quad y\mapsto y\oplus1,
\]

and

\[
W_x:\quad
x\mapsto x\oplus1,\qquad
g\mapsto g\oplus qy.
\]

Then exactly

\[
W_xW_yW_xW_y=G_q,
\]

where

\[
G_q:\quad g\mapsto g\oplus q.
\]

Thus the discrete commutator of the two schedule moves is a gauge transformation whose action is controlled by the frame variable.

## Autonomous Hamiltonian

Take

\[
H_\diamond
=
J_x(I-W_x)+J_y(I-W_y),
\qquad J_x,J_y>0.
\]

Because \(W_x^2=W_y^2=I\), both terms are positive semidefinite.

Every zero-energy state obeys

\[
W_x|\Psi\rangle=W_y|\Psi\rangle=|\Psi\rangle.
\]

Therefore automatically

\[
G_q|\Psi\rangle
=
W_xW_yW_xW_y|\Psi\rangle
=
|\Psi\rangle.
\]

**No separate gauge projector is required.**
Gauge invariance is forced by simultaneous zero frustration of the local schedule moves.

For \(J_x=J_y=1\), exact diagonalisation gives:

\[
\dim \ker H_\diamond=3,
\]

and

\[
\Delta=2-\sqrt2.
\]

More generally the smallest nonzero eigenvalue is

\[
\Delta(J_x,J_y)
=
J_x+J_y-\sqrt{J_x^2+J_y^2}>0
\]

throughout the open quadrant \(J_x,J_y>0\).

## Interpretation

This is an exact finite mechanism by which

\[
\text{local schedule consistency}
\Longrightarrow
\text{frame-dependent spatial gauge invariance}
\]

inside the low-energy sector of an autonomous Hamiltonian.

It is stronger than a hand-imposed gauge penalty, but it is still an existence construction. The remaining task is to replace the frame bit \(q\) by the relational spin-frame inverse metric structure and place this local algebra in an extended phase supporting the two TT modes.
