import numpy as np
from scipy.linalg import eigh,eigvalsh
from scipy.sparse.csgraph import connected_components,shortest_path
from fresh_window import c4,energy

m=7;n=m**3
index=lambda x,y,z:(x%m*m+y%m)*m+z%m
def inverse(s):
    a,b,c=s;return (-a,-b,-c+a*b)
def right(u,s):
    x,y,z=u;a,b,c=s;return (x+a,y+b,z+c+x*b)
def graph(gens):
    A=np.zeros((n,n),np.int8)
    ss=gens+[inverse(g) for g in gens]
    for x in range(m):
     for y in range(m):
      for z in range(m):
       u=(x,y,z);i=index(*u)
       for s in ss:
        v=right(u,s);A[i,index(*v)]=1
    return A

genlist=[((1,0,0),(0,1,0),(0,0,1))]
for a,b in [(1,1),(1,2),(2,1),(1,0),(0,1),(2,2),(2,3)]:
 for c in range(m):genlist.append(((1,0,0),(0,1,0),(a,b,c)))
rows=[]
for gs in genlist:
 A=graph(list(gs))
 if np.any(A.sum(1)!=6) or np.trace(A.astype(np.int64)@A@A):continue
 if connected_components(A)[0]!=1:continue
 E=energy(A,.104,.30);C=c4(A)/n
 w=eigvalsh(np.eye(n)-A/6)
 d=[]
 for t in (5,10):
  z=np.exp(-t*w);d.append(2*t*np.dot(w,z)/z.sum())
 rows.append((E,gs,C,*d,float(w[1])))
print('valid',len(rows))
for row in sorted(rows)[:20]:print(row)
