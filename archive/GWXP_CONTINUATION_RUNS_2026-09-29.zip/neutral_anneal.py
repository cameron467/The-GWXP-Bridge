import argparse
import numpy as np
from fresh_window import energy,metrics,valid

p=argparse.ArgumentParser()
p.add_argument('start');p.add_argument('steps',type=int);p.add_argument('seed',type=int)
p.add_argument('--u',type=float,default=.104);p.add_argument('--kap',type=float,default=.30)
p.add_argument('--t0',type=float,default=.00003);p.add_argument('--t1',type=float,default=.000002)
a=p.parse_args()
A=np.load(a.start)['A'].astype(np.int8);rng=np.random.default_rng(a.seed)
E=energy(A,a.u,a.kap);best=A.copy();emin=E;acc=0;up=0
print('START',E,metrics(A),flush=True)
for t in range(1,a.steps+1):
    ed=np.argwhere(np.triu(A,1))
    for _ in range(5000):
        i,j=rng.integers(len(ed),size=2)
        if i==j:continue
        B=valid(A,ed[i],ed[j],int(rng.integers(2)))
        if B is not None:break
    else:raise RuntimeError('no local proposals')
    Eb=energy(B,a.u,a.kap)
    temp=a.t0*(a.t1/a.t0)**((t-1)/max(a.steps-1,1))
    if Eb<E or rng.random()<np.exp((E-Eb)/temp):
        up+=int(Eb>E);A,E=B,Eb;acc+=1
        if E<emin:emin=E;best=A.copy()
    if t%200==0:print('STEP',t,'accepted',acc,'uphill',up,'current',E,metrics(A),'best',emin,metrics(best),flush=True)
np.savez_compressed(f'work/anneal_N{len(A)}_s{a.seed}_best.npz',A=best,E=emin,attempts=a.steps,accepted=acc,uphill=up)
np.savez_compressed(f'work/anneal_N{len(A)}_s{a.seed}_final.npz',A=A,E=E,attempts=a.steps,accepted=acc,uphill=up)
