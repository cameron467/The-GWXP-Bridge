# GWXP continuation — 29 September 2026

Source: GWXP_MASTER_ROLLOVER_PACKAGE_2026-09-29(1).zip. This is an additive research note; retain the master handoff's killed and corrected claims.

## Fresh parent-only tests at g=3, U=0.104, kappa=0.30, eps=0.025

Energy per vertex E = -Tr exp(3A/6)/N + U sum_edges[exp(3A/6)_{ij}^2]/N - kappa Tr log(1.025 I - A/6)/N. Degree 6, triangle-free, local valid 2-switch; zero-temperature acceptance depends exclusively on exact E. No square, curvature, dimension or isotropy steering. Script `fresh_window.py`. Recomputed the earlier N=128 archived energy at old couplings to 8.9e-16 accuracy.

- N=128, fresh bipartite random 6-regular seed 22917: E -1.739632661, C4/N 1.359375 -> after 500+1500 proposals E -1.748432235, C4/N 4.210938, heat d_s(5) 3.35613. 190 accepted total.
- N=128, independent seed 99173: E -1.739611260, C4/N 1.359375 -> after 1500 proposals E -1.747817133, C4/N 3.914063, d_s(5) 3.40140. 184 accepted.
- N=216, fresh seed 53107: E -1.738519014, C4/N 0.814815 -> after 900+1400 proposals E -1.748361831, C4/N 3.388889, d_s(5) 3.63083. 335 accepted.
- N=344, archived generic triangle-free double cover (not coordinate-generated): E -1.737536632, C4/N 0.494186, d_s(5) 4.51745 -> after 900+2000 proposals E -1.747764733, C4/N 2.965116, d_s(5) 3.77797. 558 accepted.

These are autonomous downhill condensation trajectories in the new coupling window. The N=344 endpoint is still ABOVE the structured competitor energy; no spontaneous mature 3D phase has been shown at the third size. The starts are generic triangle-free bipartite graphs, not unrestricted random regular graphs. Tests are zero-temperature trajectories, not a mixing/thermodynamic demonstration.

## Exact leading four-cycle drive

For degree-6 simple graphs, Tr A^4 = 66 N + 8 C4. Expanding -Tr exp(3A/6)/N gives the exact fourth-order motif coefficient

    Delta E_walk^(4) = -(3^4 / (3 * 6^4)) Delta C4/N = -(1/48) Delta C4/N.

The determinant's fourth-order coefficient has the opposite sign:

    Delta E_det^(4) = [2 kappa/(6^4 * 1.025^4)] Delta C4/N.

For kappa=.30 this is about +0.0004195 Delta C4/N, much smaller than the walk's fourth-order coefficient. Higher closed walks and the nonlinear edge-capacity term substantially cancel the raw walk incentive. At a late N=128 state, an exact 120-valid-move sample had Corr(Delta C4, Delta E)=-0.8044. For Delta C4=+1 (4 sampled moves), the mean exact contributions [walk, capacity, determinant] were [-0.000223582,+0.000206693,+0.000008921], net -0.000007968. At Delta C4=-10 (14 moves), the means were [+0.002100999,-0.001875167,-0.000069313], net +0.000156519. This verifies the competition in the full functional but not a complete closed reaction-coordinate theory.

## Structured controls and interpretation

An infinite periodic Fourier evaluation at the same couplings gave cubic Z^3 E=-1.748264658; rank-2 Cayley generators (1,0),(0,1),(1,2) E=-1.748222806. A scan of 75 other non-degenerate triangle-free rank-2 integer-generator pairs through 8 and 796 triangle-free rank-1 three-generator choices through (p,q)=(34,45) found no lower result than the cubic control (excluding duplicate/degree-deficient generators). This is a bounded family search, not an all-graph ground-state proof. The old-coordinate-seeded N=128 state re-evaluates to -1.748759124; it is NOT an autonomous new-coupling state. A relation-guided archived N=344 state at C4/N=4.596 re-evaluates to -1.748800119, also NOT an autonomous new-coupling discovery. The freshly found N=128 and N=216 endpoints are below the infinite controls by 0.000168 and 0.000097 respectively, but different finite sizes cannot settle the bulk energy ordering. Fresh N=344 endpoint is 0.000500 above cubic.

## Decisive next test

Continue independent N=344 runs from generic and unrestricted graph starts at the new couplings with neutral proposals and finite-temperature/soft quantum local dynamics, then compare same-size periodic/Cayley controls and finite-size scaling. Determine whether the N=344 trajectory reaches C4/N around 4-5 and stays below broadened rank-2/3 structured adversaries. Repeat at other points (0.35,0.103) and (0.40,0.102); test robust open window. No gravity closure claim follows from the current graph-only result.

## Second pass: N=344 neutral exploration and window correction

A 2,000-step neutral local Metropolis anneal from the N=344 zero-temperature endpoint (temperature of energy *density* from 3e-5 to 2e-6) accepted 440 moves, including 213 uphill moves. Its best state was the starting state; the cooled endpoint was E=-1.747627574. This schedule did not cross the competitor.

A separate **energy-only basin search** picked the lowest-E move from 16 independent valid local proposals per step, accepting only when lower. This selection rule uses no C4/dimension/curvature term but is an optimizer, not a microscopic dynamics or unbiased single-proposal nucleation proof. After 125+125+200+200 such selection steps from the saved generic-parent trajectory, its final N=344 state is:

    E/N = -1.7504797994075174
    C4/N = 4.151162790697675
    gap = 0.12318853471049884
    heat d_s(t=3,5,8,10,12,16) = 3.236, 3.482, 3.518, 3.543, 3.487, 3.029
    mean B2,B3,B4 = 25.843, 77.186, 183.733
    triangle-free, connected, degree 6 at all 344 vertices
    local square-participation CV ~0.227

The earlier archived relation-guided N=344 state, re-evaluated at the same couplings, has E=-1.748800119, C4/N=4.596, heat d_s(5)=3.298, mean B3=73.134. An external-coordinate-seeded N=344 3D state has E=-1.748363970, d_s(5)=3.301, mean B3=68.901. The new lower-E graph is LESS obviously 3D-like than those controls, despite relation condensation. A finite 7x7x7 cubic graph has d_s(5)=3.650 and E=-1.747944530 at the same couplings; d_s(5) alone is not a dimension verdict. At t=10 the cubic gives 3.271 versus fresh 3.543. A thermodynamic diagnosis is open.

Same-size N=344 structured competitors: 11,399 connected triangle-free 6-regular circulants with one unit generator plus a 67,456-valid random sample of general connected triangle-free circulants had best E=-1.748190564, e.g. generators (1,61,123) mod 344. A Z8 x Z43 rank-2 Cayley scan gave best -1.748006622. The fresh graph beats those tested same-size controls by at least 0.0022892 in E/N. These are bounded searches, not exhaustive graph-ground-state proofs. The infinite rank-2 and cubic controls are -1.748222806 and -1.748264658 respectively.

### Fixed-state no-overlap at the proposed coupling window

At g=3 the energy is linear in (1,U,kappa) for any fixed graph. Decompose E=W+U C+kappa D:

    fresh N344:       (-2.0583674701, 2.7094932764, 0.08700123317)
    archived 3D-like: (-2.0727477690, 2.8560477312, 0.08972895455)
    N344 circulant:   (-2.1162236868, 3.2517064088, 0.09951885)

At kappa=0.30 the archived 3D-like state beats fresh only for U<0.092539, but beats the circulant only for U>0.102459: no overlap. The same fixed-state failure holds at kappa=.08,.20,.40,.60,1.0. At the four representative previously proposed points (kappa,U)=(.25,.105),(.30,.104),(.35,.103),(.40,.102), fresh beats that archived 3D-like state by respectively ~.001690,.001680,.001670,.001659 per vertex. This DEMOTES the old inference that beating rank-2 and cubic alone secures a 3D phase. It does not kill all couplings or prove the fresh basin's thermodynamic dimension; the graphs may rearrange when couplings change.

Next: independent starts and replica/anneal dynamics at each coupling, same-size expanded graph adversaries, and dimension scaling at multiple N for states selected by the same neutral protocol. Preserve the distinction between single-proposal autonomous dynamics and energy-only multiple-proposal basin search.

## Independent N=344 replication (same protocol)

Second independent generic triangle-free bipartite degree-6 start (seed 91873, no external coordinates), same g=3,U=.104,kappa=.30:

- Start E=-1.7371689231, C4/N=.430233, d_s(5)=4.53752.
- After 2,200 blind zero-T exact-energy local proposals: E=-1.7471966495, C4/N=2.720930, d_s(5)=3.85800.
- After 700 more blind proposals: E=-1.7479527111, C4/N=2.985465, d_s(5)=3.78361.
- Then 300+175+175 energy-only best-of-16 valid local proposal steps: E=-1.7504530845, C4/N=4.090116, gap=.133475, d_s(3,5,10)=(3.24093,3.49118,3.53403).

Matched first trajectory at 2,900 blind plus 650 best-of-16 steps: E=-1.7504797994, C4/N=4.151163, gap=.123189, d_s(3,5,10)=(3.23639,3.48201,3.54336). Difference in E is only 2.67e-5 per vertex; dimension profiles agree to roughly .01 at these times. This is strong **finite numerical basin reproducibility under the same optimized search protocol**. It does not establish mixing of single-proposal microscopic dynamics or thermodynamic 3D scaling.

Next decisive pass: optimize independent N=128,216,344 and preferably 512 states with a matched proposal budget/selection protocol; compare E/N, heat curves at diffusion times scaled with system length, IDOS, ball growth, and local rank-4 orientation diagnostics. Check whether the apparent 3.5-ish intermediate heat dimension trends toward 3 or persists above 3. Broaden adversaries and rerun independent starts at alternative couplings before claiming a 3D phase.

## Matched energy-only search at three sizes

Using the saved generic parent-only states (N128 after 2000 blind proposals; N216 after 2300; N344 after 2900) followed by 650 best-of-16 neutral local energy proposals:

| N | E/N | C4/N | gap | mean B2/B3/B4 | heat d_s(t=3,5,8,10) |
|---|---|---|---|---|---|
|128| -1.749729475 | 4.671875 | .1847 | 24.55 / 64.06 / 108.89 | 3.186 / 3.286 / 2.960 / 2.646 |
|216| -1.750227752 | 4.148148 | .1607 | 25.62 / 73.19 / 151.27 | 3.235 / 3.460 / 3.371 / 3.237 |
|344 first| -1.750479799 | 4.151163 | .1232 | 25.84 / 77.19 / 183.73 | 3.236 / 3.482 / 3.518 / 3.543 |
|344 second| -1.750453084 | 4.090116 | .1335 | 25.79 / 76.29 / 180.03 | 3.241 / 3.491 / 3.518 / 3.534 |

Cubic lattice controls at sizes 125,216,343 have heat d_s(t=3,5,8,10) respectively (3.310,3.550,2.977,2.437), (3.320,3.636,3.348,3.040), and (3.322,3.650,3.457,3.271). The peak of a finite cubic control itself rises with size; a fixed-t dimension comparison is not a thermodynamic extrapolation. The N344 GWXP basin is flatter/higher at later t than the cubic control. Energy scaling from these states is promising for a low-energy disordered basin, but their limiting dimension is unresolved. N512 plus properly scaled diffusion/IDOS/ball-growth analysis is the next necessary test. Treat this as a matched *selection-rule* comparison, not a standardized equilibration proof: the blind starting lengths differ slightly by size.

## N=512 interim autonomous test

A fresh generic bipartite triangle-free degree-6 graph (seed 512901, no coordinate generation) at g=3,U=.104,kappa=.30 began E=-1.737051972, C4/N=.335938, heat d_s(5)=4.62910. After 100+900 **blind single-proposal zero-T parent-energy-only** local switches (new seed 512902 for continuation), E=-1.743564454, C4/N=1.572266, d_s(5)=4.24402 and d_s(10)=4.70391. This extends the autonomous relation-condensation drive to a fourth graph size. The endpoint is early/expander-like and cannot yet be used for thermodynamic dimensional scaling. Saved state: fresh_N512_s512902_u0.104_k0.3.npz. Continue in checkpointed batches, then a matched neutral basin search if feasible.

## N=512 second checkpoint / current stop boundary

After 1,000 additional blind zero-T parent-only local attempts from the 1,000-attempt state (seed 512903), the N=512 trajectory at 2,000 total attempts has E=-1.7454225145, C4/N=2.054688, spectral gap=.172307, heat d_s(5)=4.08828 and d_s(10)=4.48653. It is still descending. This is not a mature basin, so do not plot this datum beside the 650-pool optimized N=128/216/344 states as if it were size scaling. Saved `fresh_N512_s512903_u0.104_k0.3.npz`.

**Stop boundary:** all posted results and scripts through this point are checkpointed. The next instance can continue N=512 from this exact snapshot in short blocks, but should avoid long uncheckpointed eigensolve batches. The remaining thermodynamic dimension test is still OPEN. Current N=128/216/344 heat curves are finite-size ambiguous and cannot establish 3D or >3D.

## N512 extended checkpoint: 4,000 blind + 200 energy-only selections

From the previously saved 2,000-attempt N512 state, 1,000+1,000 further single-proposal zero-T parent-only local moves (seeds 512904/512905) reached E=-1.7473895278, C4/N=2.632813, heat d_s(5)=3.91546 and d_s(10)=4.26206. Then 100+100 best-of-16 neutral energy-only local selections (seeds 512906/512907) reached E=-1.7484618000, C4/N=3.001953, gap=.151564, d_s(5)=3.80927, d_s(10)=4.12623. This N512 state beats the tested rank-2/cubic infinite controls in energy but remains structurally too early for a thermodynamic dimension comparison. The search continues in further saved blocks. Files `fresh_N512_s512905_u0.104_k0.3.npz` and `pool_N512_s512907_p16.npz`.

## N512 continuation to 4,000 blind + 450 best-of-16 selections

The N512 state after 4,000 blind exact-parent-energy local proposals had E=-1.7473895278, C4/N=2.632813. Subsequent independent best-of-16 local proposal batches 100+100+100+150 (seeds 512906-512909) reached E=-1.7494802395, C4/N=3.410156, spectral gap=.140033, heat d_s(3,5,10)=(3.30264,3.69235,3.97574). The state is still descending and less locality-condensed than N344 at its 650-pool endpoint. Do not use it as an equilibrated size-scaling datum. Saved `pool_N512_s512909_p16.npz`. Another selection batch is in progress at checkpoint time.

## N512 at 800 best-of-16 selections; finite high-growth control

Continuing from 4,000 blind parent-energy-only proposals, six neutral energy-only best-of-16 local selection batches totaling 800 steps reached E=-1.7502155255, C4/N=3.732422, gap=.136215, d_s(3,5,10)=(3.27411,3.60446,3.86291). Mean radius-2/3/4/5 ball sizes are 26.55/82.89/216.54/397.12, diameter 8. The energy is below the tested infinite rank-2 and cubic controls, but it has not matched the N344 endpoint density (~4.1) or heat profile and must not yet be used as converged N512 scaling. Saved `pool_N512_s512911_p16.npz`.

As a concrete higher-growth degree-six adversary, 46 connected triangle-free Cayley graphs on finite Heisenberg H(Z7), N343, with generator triples including X,Y,Z and related skew sets were evaluated at the same coupling. The best tested E=-1.744751780, C4/N=2, d_s(5)=3.965 and d_s(10)=3.686; it loses badly to the N344 disordered state. This finite tested family does not explain the low-energy basin's faster diffusion and does not exhaust nilpotent/non-Abelian controls. Script `heisenberg_control.py`.

## N512 at 1,200 best-of-16 selections: a high-growth warning

Starting from 4,000 blind zero-T proposals, the N512 best-of-16 energy-only search reached 1,200 selections after an additional 200-step batch (seed 512913): E=-1.7507534996, C4/N=4.005859, gap=.1294845, heat d_s(t=3,5,8,10,12,16) approximately (3.251,3.540,3.680,3.807,3.875,3.657). The heat-return probability slope across t=5..12 is about 3.686. Mean radius-2/3/4/5 ball sizes are 26.11/80.25/209.16/389.58. A same-size 8^3 cubic torus has radius-2/3/4/5 balls 25/63/126/210 and infinite cubic d_s(t=10)=3.362. This is strong finite evidence that the current low-energy N512 state is more shortcut-rich/faster growing than a 3D lattice. It has not stopped descending, so its limiting basin and thermodynamic dimension remain OPEN. Do not promote this to a proof of 4D or a permanent kill of the coupling region. Saved `pool_N512_s512913_p16.npz`.

At the completed N128/216/344 endpoints, the heat d_s(10) sequence is about 2.646,3.237,3.543, while N512 at C4/N~4.0 is 3.807. Finite-size zero-mode effects and unequal equilibration could contribute, but this sequence does not support a demonstrated 3D scaling collapse. The old candidate's rank-4 gravity issues remain downstream until geometry is secured.

## N512 at 1,400 selections and lower communicability coupling test

Another 200 best-of-16 energy-only selections (seed 512914) from the N512 1,200-step state accepted 40 moves and reached E/N=-1.7509242108296266, C4/N=4.076171875, spectral gap=.1306634, heat d_s(3,5,10)=(3.24548,3.52632,3.80328). The late energy descent slows, but the high d_s(10) and gap remain. Saved `pool_N512_s512914_p16.npz`. This does not establish a thermodynamic dimension.

The exact g=3 fixed-state balance explains the earlier no-overlap: archived N344 3D-like beats fresh amorphous in the walk term by .0143803 per vertex, but loses .0152417 in U-weighted capacity and .0008183 in kappa-weighted determinant at U=.104,kappa=.30. The determinant term penalizes small Laplacian eigenvalues and can favor a more open gap. This is an interpretation of its spectral sign, not proof of a phase mechanism.

Scanning the **existing** communicability exponent g found a tiny fixed-state opening near g=2,U=.1,kappa=.3. At this point the archived N344 3D-like state E=-1.30212710145 barely beat the g3-selected fresh amorphous state E=-1.30211007774 and infinite rank-2 control E=-1.30210340963. The margin ~1.7e-5 is fragile; N512's g3-selected fresh state re-evaluated at g2 is -1.30235216, though a different size. Code `g_scan_fixed_states.py`.

Same-size g2 Fourier adversaries (`g2_adversaries.py`): 13,862 valid unit-generator circulants, best E=-1.30207116765 with (1,89,165) and equivalent triples; 126,535 valid sampled general circulants give the same best. A restricted Z8 x Z43 torus family with basis generators (1,0),(0,1) and a third signed direction (101 valid) best E=-1.30188784251. Thus these tested structured controls do not close the small initial fixed-state opening.

Equal-budget N344 **best-of-16 exact-parent-energy-only** local relaxation at g2,U=.1,kappa=.3, 300 selection steps from each saved state (100+200 with independent seeds):

| start | step | E/N | C4/N | gap | heat d_s(5),d_s(10) |
|---|---:|---:|---:|---:|---:|
| g3-selected amorphous | 0 | -1.302110078 | 4.1512 | .1232 | 3.482,3.543 |
| g3-selected amorphous | 100 | -1.302267437 | 4.3634 | .1177 | 3.424,3.484 |
| g3-selected amorphous | 300 | -1.302489002 | 4.7006 | .1092 | 3.327,3.354 |
| archived relation-guided 3D-like | 0 | -1.302127101 | 4.5959 | .1024 | 3.298,3.166 |
| archived relation-guided 3D-like | 100 | -1.302344870 | 4.8401 | .1025 | 3.244,3.131 |
| archived relation-guided 3D-like | 300 | -1.302699555 | 5.2994 | .1020 | 3.138,3.062 |

The g2-relaxed 3D-like seeded state leads by .00021055 per vertex at equal selection budget, and both branches still descend. The amorphous branch's geometry moves toward lower apparent dimension. This is **not autonomous genesis of 3D**: one start inherited a relation-guided 3D graph, the other inherited a g3-selected state, and best-of-16 selection is an optimizer. Follow up with generic coordinate-free starts and blind single-proposal dynamics at g2; then equal search budgets and size scaling, including wider competitors. Saved endpoints `g2_pool_N344_s22003_p16.npz` and `g2_pool_N344_s22004_p16.npz` (intermediate states s22001/22002), script `g2_pool_test.py`.

## Coordinate-free N344 genesis at g=2

A **new** generic 6-regular bipartite triangle-free N344 graph generated from random disjoint perfect matchings (seed 22005, no coordinates) started E=-1.2979565481,C4/N=.4448, gap=.2685,d_s(5)=4.535. Under 2,500 blind single-proposal zero-T local 2-switch attempts at g2,U=.1,kappa=.3 it accepted 559 moves and reached E=-1.3008857977,C4/N=2.9448,gap=.1525,d_s(5,10)=(3.789,3.808). This independently establishes an autonomous square-condensation drive at g2. It is not an equilibrated 3D state.

Then **energy-only best-of-16** local selection for 300+500 steps (seeds 22006/22007) accepted 189+170 and reached E=-1.30277810855,C4/N=5.34593,gap=.10336,d_s(3,5,10)=(3.12626,3.14004,3.09688). At 300 selections it was E=-1.301988404,C4/N=4.2064,d_s(10)=3.4430. The final generic branch slightly undercuts the relation-guided seeded branch's 300-selection endpoint (-1.302699555), and they now have similar gap and heat profile, although they were not given equal total selection budget and remain descending. This is evidence that an energy-only search can access a more 3D-like low-energy graph without coordinate seeds at this candidate coupling; no equilibrium or thermodynamic phase claim follows. Saved `fresh_N344_s22005_u0.1_k0.3_g2.0.npz`, `g2_pool_N344_s22006_p16.npz`, `g2_pool_N344_s22007_p16.npz`.

At N344 the final generic branch mean B2/B3/B4/B5 is 24.256/69.157/164.238/276.872, versus seeded branch 24.134/67.669/159.453/272.116. Both remain more expansive at radius 4 than the cubic 7^3 torus control (B4=123); heat d_s(10) near 3 by itself does **not** certify cubic volume growth or large-N locality. The g3-selected fresh N344 graph has 25.843/77.186/183.733/295.977. An N512 challenge at g2 is pending.

## N512 competing branch at g2

The coordinate-free N512 g3-selected 1,400-selection state re-evaluated at g2,U=.1,kappa=.3 starts E=-1.30235215948,C4/N=4.07617,gap=.13066,d_s(10)=3.80328. A further 300 best-of-16 local exact-g2-energy selections (seed 22008) accepted 54 moves and reached E=-1.302491314997,C4/N=4.29297,gap=.12746,d_s(3,5,10)=(3.22501,3.45847,3.68882). It remains much more shortcut-rich than the N344 g2 generic branch and is still descending, but has a higher E/N than the N344 generic endpoint -1.30277811. Cross-size energy comparisons cannot establish which thermodynamic branch wins because equilibration histories are unequal and finite-size corrections differ. This N512 start was optimized at g3, so it is a metastability challenge, not an independent g2 generic-start trajectory. Saved `g2_pool_N512_s22008_p16.npz`.

At this checkpoint g2 is a **candidate** for coordinate-free access to a lower-energy, more local finite basin, with an unresolved high-growth competitor and no thermodynamic 3D identification. The next discriminating calculation is matched g2 dynamics across N, longer basin search or annealing from the N512 branch, and volume/IDOS scaling rather than a single heat-slope value. Gravity closure remains downstream.

## Matched g2 generic starts at N128,216,344

Each coordinate-free triangle-free 6-regular generic bipartite graph received 2,500 blind zero-T single-proposal exact-parent-energy local switch attempts at g2,U=.1,kappa=.3, followed by 800 best-of-16 energy-only local selection steps. Different seeds, same move budget; these are not equilibrated or equal-energy-convergence states.

| N | blind endpoint E/N,C4/N | selection endpoint E/N | C4/N | gap | d_s(3,5,10) | B2/B3/B4/B5 |
|---:|---|---:|---:|---:|---|---|
|128| -1.301324391,5.09375 | -1.302762008 | 7.265625 | .11304 | 2.958,2.671,2.325 | 21.30/50.67/94.42/123.05 |
|216| -1.300986249,3.68519 | -1.303093061 | 6.620370 | .09921 | 3.014,2.824,2.653 | 22.45/58.60/125.15/189.19 |
|344| -1.300885798,2.94477 | -1.302778109 | 5.345930 | .10336 | 3.126,3.140,3.097 | 24.26/69.16/164.24/276.87 |

Corresponding cubic torus B2/B3/B4/B5 at 5^3,6^3,7^3 are respectively 25/57/93/117, 25/60/108/156, 25/63/123/195. Radius-four excess over cubic grows with N across these **unequilibrated** graph states, while square density declines with N and the best-of-16 acceptance remains appreciable. This can be a lag in larger-graph condensation; it prevents a dimensional extrapolation. N128 is not exactly 5^3 (125), so the cubic comparison is approximate. The strong finite-size zero mode causes heat d_s(10) to vary with N even for a cubic torus. Saved fresh and pool endpoints with seeds 22011/22012 (N128), 22009/22010 (N216), 22005/22007 (N344). The N344 generic search should be extended before interpreting the apparent trend.
