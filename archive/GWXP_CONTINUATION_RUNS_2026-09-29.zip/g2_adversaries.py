"""Same-size Fourier adversaries to a narrow g=2 fixed-state window."""
import numpy as np

N=344; U=.1; K=.3; G=2.; theta=2*np.pi*np.arange(N)/N
cs=np.cos(np.outer(np.arange(1,N//2+1),theta))

def energy(gens):
    lam=sum(cs[g-1] for g in gens)/3
    z=np.exp(G*lam)
    return float(-z.mean()+U*sum(np.mean(z*cs[g-1])**2 for g in gens)-K*np.log(.025+1-lam).mean())

def valid(gens):
    signed=[s*g%N for g in gens for s in (1,-1)]
    return len(set(signed))==6 and np.gcd.reduce((N,*gens))==1 and not any((x+y+z)%N==0 for x in signed for y in signed for z in signed)

rows=[]
for b in range(2,N//2):
    for c in range(b+1,N//2):
        gens=(1,b,c)
        if valid(gens):rows.append((energy(gens),gens))
print('unit-generator circulants',len(rows),'best',sorted(rows)[:10],flush=True)

rng=np.random.default_rng(800702);rows=[]
for _ in range(150000):
    gens=tuple(sorted(rng.choice(np.arange(1,N//2),size=3,replace=False)))
    if valid(gens):rows.append((energy(gens),gens))
print('general circulants sampled valid',len(rows),'best',sorted(rows)[:10],flush=True)

# Z8 x Z43, six signed generators (a,b). Enumerate a low-integer set of
# representatives, including non-unit mixed directions. Eigenvalues via DFT.
theta1=2*np.pi*np.arange(8)/8;theta2=2*np.pi*np.arange(43)/43
co={}
for a in range(5):
    for b in range(22):co[a,b]=np.cos(a*theta1[:,None]+b*theta2[None,:])
def tvalid(gens):
    mod=lambda p:(p[0]%8,p[1]%43)
    ss={mod(p) for a,b in gens for p in ((a,b),(-a,-b))}
    if len(ss)!=6:return False
    if any(mod((x[0]+y[0]+z[0],x[1]+y[1]+z[1]))==(0,0) for x in ss for y in ss for z in ss):return False
    reach={(0,0)};front={(0,0)}
    for _ in range(344):
        new={mod((x[0]+y[0],x[1]+y[1])) for x in front for y in ss}-reach
        if not new:break
        reach|=new;front=new
    return len(reach)==344
dirs=[(a,b) for a in range(5) for b in range(22) if (a,b)!=(0,0)]
rows=[]
for p in dirs:
    gens=((1,0),(0,1),p)
    if not tvalid(gens):continue
    lam=sum(co[p] for p in gens)/3;z=np.exp(G*lam)
    e=float(-z.mean()+U*sum(np.mean(z*co[p])**2 for p in gens)-K*np.log(.025+1-lam).mean())
    rows.append((e,gens))
print('torus tested',len(rows),'best',sorted(rows)[:10],flush=True)
