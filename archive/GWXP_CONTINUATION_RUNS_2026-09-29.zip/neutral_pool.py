import argparse
import numpy as np
from fresh_window import energy,metrics,valid
p=argparse.ArgumentParser();p.add_argument('start');p.add_argument('steps',type=int);p.add_argument('pool',type=int);p.add_argument('seed',type=int)
p.add_argument('--u',type=float,default=.104);p.add_argument('--kap',type=float,default=.30)
a=p.parse_args();rng=np.random.default_rng(a.seed)
A=np.load(a.start)['A'].astype(np.int8);E=energy(A,a.u,a.kap);acc=0
print('START',E,metrics(A),flush=True)
for t in range(1,a.steps+1):
    ed=np.argwhere(np.triu(A,1));pick=None;Ep=E
    for _ in range(a.pool):
        for __ in range(5000):
            i,j=rng.integers(len(ed),size=2)
            if i==j:continue
            B=valid(A,ed[i],ed[j],int(rng.integers(2)))
            if B is not None:break
        else:raise RuntimeError('no local proposals')
        Eb=energy(B,a.u,a.kap)
        if Eb<Ep:Ep=Eb;pick=B
    if pick is not None:A,E=pick,Ep;acc+=1
    if t%25==0:print('STEP',t,'acc',acc,'E',E,metrics(A),flush=True)
np.savez_compressed(f'work/pool_N{len(A)}_s{a.seed}_p{a.pool}.npz',A=A,E=E,accepted=acc,attempts=a.steps,pool=a.pool)
