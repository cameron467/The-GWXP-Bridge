import argparse
import numpy as np
from scipy.linalg import eigh

def energy(A, u, kap, g=3.0):
    n = len(A)
    w, v = eigh(A.astype(float)/6, check_finite=False)
    e = np.exp(g*w)
    edges = np.argwhere(np.triu(A, 1))
    k = np.sum(v[edges[:, 0]] * v[edges[:, 1]] * e, axis=1)
    return float(-e.mean() + u*np.sum(k**2)/n - kap*np.log(.025+1-w).mean())

def c4(A):
    b=A.astype(np.int16)@A.astype(np.int16)
    x=b[np.triu_indices(len(A), 1)].astype(np.int64)
    return int(np.sum(x*(x-1)//2)//2)

def metrics(A):
    n=len(A)
    w=eigh(np.eye(n)-A/6, eigvals_only=True, check_finite=False)
    ds={t:float(2*t*np.dot(w,np.exp(-t*w))/np.exp(-t*w).sum()) for t in (3,5,10)}
    return c4(A)/n, float(w[1]), ds

def valid(A, e1, e2, mode):
    a,b=e1; c,d=e2
    if len({a,b,c,d})<4:return None
    adds=[(a,c),(b,d)] if mode==0 else [(a,d),(b,c)]
    if any(A[x,y] for x,y in adds):return None
    B=A.copy()
    for x,y in (e1,e2):B[x,y]=B[y,x]=0
    if any(np.dot(B[x],B[y]) for x,y in adds):return None
    # Locality condition used in the rollover: each new edge spans at most 3 hops after deletion.
    for x,y in adds:
        reach={x}; front={x}
        for _ in range(3):
            front=set(int(v) for p in front for v in np.flatnonzero(B[p]))-reach
            reach |= front
        if y not in reach:return None
    for x,y in adds:B[x,y]=B[y,x]=1
    return B

def run(n, seed, steps, u, kap, start=None, g=3.0):
    rng=np.random.default_rng(seed)
    if start:
        A=np.load(start)['A'].astype(np.int8)
    else:
        A=np.zeros((n,n),dtype=np.int8)
        # Six random perfect matchings form a generic simple bipartite 6-regular graph.
        m=n//2
        for _ in range(6):
            for retry in range(100000):
                perm=rng.permutation(m)
                if not np.any(A[np.arange(m),m+perm]):break
            else:raise RuntimeError('failed to find disjoint matching')
            A[np.arange(m),m+perm]=A[m+perm,np.arange(m)]=1
    E=energy(A,u,kap,g); accepted=0
    print('START',n,seed,u,kap,g,E,metrics(A),flush=True)
    for step in range(steps):
        ed=np.argwhere(np.triu(A,1)); B=None
        for _ in range(3000):
            i,j=rng.integers(len(ed),size=2)
            if i==j:continue
            B=valid(A,ed[i],ed[j],int(rng.integers(2)))
            if B is not None:break
        if B is None:break
        Eb=energy(B,u,kap,g)
        if Eb<E:A,E=B,Eb;accepted+=1
        if (step+1)%100==0:
            print('STEP',step+1,accepted,E,metrics(A),flush=True)
    suffix='' if g==3.0 else f'_g{g}'
    np.savez_compressed(f'work/fresh_N{n}_s{seed}_u{u}_k{kap}{suffix}.npz',A=A,E=E,accepted=accepted,attempts=steps,g=g)
    print('END',n,seed,accepted,E,metrics(A),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('n',type=int);p.add_argument('seed',type=int);p.add_argument('steps',type=int)
    p.add_argument('u',type=float);p.add_argument('kap',type=float)
    p.add_argument('--start');p.add_argument('--g',type=float,default=3.0)
    a=p.parse_args();run(a.n,a.seed,a.steps,a.u,a.kap,a.start,a.g)
