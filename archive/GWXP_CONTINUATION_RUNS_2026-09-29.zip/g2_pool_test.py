"""Adversarial local relaxation of fixed states at g=2, U=.1, kappa=.3."""
import sys
import numpy as np
from fresh_window import energy,metrics,valid

path,steps,pool,seed=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])
rng=np.random.default_rng(seed)
A=np.load(path)['A'].astype(np.int8)
E=energy(A,.1,.3,g=2.0);accepted=0
print('START',path,E,metrics(A),flush=True)
for t in range(1,steps+1):
    ed=np.argwhere(np.triu(A,1));best=None;Eb=E
    for _ in range(pool):
        for __ in range(5000):
            i,j=rng.integers(len(ed),size=2)
            if i==j:continue
            B=valid(A,ed[i],ed[j],int(rng.integers(2)))
            if B is not None:break
        else:raise RuntimeError('no valid proposal')
        b=energy(B,.1,.3,g=2.0)
        if b<Eb:Eb=b;best=B
    if best is not None:A,E=best,Eb;accepted+=1
    if t%25==0:print('STEP',t,'accepted',accepted,'E',E,'metrics',metrics(A),flush=True)
out=f'work/g2_pool_N{len(A)}_s{seed}_p{pool}.npz'
np.savez_compressed(out,A=A,E=E,accepted=accepted,attempts=steps,pool=pool,g=2.,u=.1,kappa=.3)
print('END',out,E,accepted,metrics(A),flush=True)
