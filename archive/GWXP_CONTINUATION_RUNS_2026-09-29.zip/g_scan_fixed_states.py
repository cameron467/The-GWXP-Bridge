import numpy as np
from scipy.linalg import eigh
b='work/GWXP_MASTER_ROLLOVER_PACKAGE_2026-09-29/02_LATEST_CODE_AND_DATA/'
files={'fresh':'work/pool_N344_s344935_p16.npz','3Drel':b+'gwxp_N344_relation_condense312.npz','3Dext':b+'gwxp_external_N344_parent_relaxed30.npz'}
cache={}
for name,p in files.items():
 A=np.load(p)['A'];n=len(A);w,V=eigh(A.astype(float)/6);ed=np.argwhere(np.triu(A,1));ev=V[ed[:,0]]*V[ed[:,1]]
 cache[name]=(w,ev,n,-np.log(.025+1-w).mean())
L=256;x=2*np.pi*np.arange(L)/L;a,c=np.meshgrid(x,x,indexing='ij');lam2=(np.cos(a)+np.cos(c)+np.cos(a+2*c))/3;dirs2=[np.cos(a),np.cos(c),np.cos(a+2*c)]
L=96;x=2*np.pi*np.arange(L)/L;co=np.cos(x);lam3=(co[:,None,None]+co[None,:,None]+co[None,None,:])/3

def terms(g):
 out={}
 for name,(w,ev,n,D) in cache.items():
  z=np.exp(g*w);out[name]=np.array([-z.mean(),np.sum((ev@z)**2)/n,D])
 z=np.exp(g*lam2);out['rank2']=np.array([-z.mean(),sum(np.mean(z*q)**2 for q in dirs2),-np.log(.025+1-lam2).mean()])
 z=np.exp(g*lam3);out['cubic']=np.array([-z.mean(),3*np.mean(z*co[:,None,None])**2,-np.log(.025+1-lam3).mean()])
 return out
for g in np.arange(2.,5.01,.25):
 rows=terms(g);success=[]
 for K in np.linspace(.05,.60,56):
  for d in ['3Drel','3Dext']:
   # Evaluate exact lower envelope on U grid, robust to inequality directions.
   U=np.linspace(.01,.5,2000);p=np.array([1.,0.,K]);ener={k:r[0]+U*r[1]+K*r[2] for k,r in rows.items()}
   mask=(ener[d]<ener['fresh'])&(ener[d]<ener['rank2'])&(ener[d]<ener['cubic'])
   if mask.any():success.append((K,d,float(U[mask][0]),float(U[mask][-1])))
 at03=[s for s in success if abs(s[0]-.3)<.005]
 print('g',round(g,2),'n_windows',len(success),'k.3',at03[:2],'first',success[:2],flush=True)
