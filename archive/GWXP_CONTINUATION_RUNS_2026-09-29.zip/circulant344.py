import numpy as np

N=344;U=.104;KAP=.30;theta=2*np.pi*np.arange(N)/N
cs=np.cos(np.outer(np.arange(1,N//2+1),theta))

def triangle_free(gens):
    signed=[s*g%N for g in gens for s in (1,-1)]
    return not any((x+y+z)%N==0 for x in signed for y in signed for z in signed)

results=[]
for b in range(2,100):
    for c in range(b+1,N//2):
        gens=(1,b,c)
        if not triangle_free(gens):continue
        lam=(cs[0]+cs[b-1]+cs[c-1])/3
        exp=np.exp(3*lam)
        k=[np.mean(exp*cs[s-1]) for s in gens]
        E=-exp.mean()+U*sum(x*x for x in k)-KAP*np.log(.025+1-lam).mean()
        results.append((float(E),gens))
print('tested',len(results))
for row in sorted(results)[:20]:print(row)
