import numpy as np
N=344;U=.104;KAP=.30
for Lx,Ly in [(8,43),(4,86)]:
    kx=2*np.pi*np.arange(Lx)[:,None]/Lx
    ky=2*np.pi*np.arange(Ly)[None,:]/Ly
    gens0=((1,0),(0,1));out=[]
    for p in range(Lx):
        for q in range(Ly):
            gens=(*gens0,(p,q))
            sgn=[((s*a)%Lx,(s*b)%Ly) for a,b in gens for s in (1,-1)]
            if len(set(sgn))!=6:continue
            if any(((a[0]+b[0]+c[0])%Lx,(a[1]+b[1]+c[1])%Ly)==(0,0) for a in sgn for b in sgn for c in sgn):continue
            cos=[np.cos(a*kx+b*ky) for a,b in gens]
            lam=sum(cos)/3; e=np.exp(3*lam)
            cap=sum(np.mean(e*t)**2 for t in cos)
            en=-e.mean()+U*cap-KAP*np.log(.025+1-lam).mean()
            out.append((float(en),p,q))
    print(Lx,Ly,'tested',len(out),'best',sorted(out)[:10])
