from __future__ import annotations
import copy
from pathlib import Path
import numpy as np
import scipy.linalg as la

from .model import build_model, restrict
from .diagnostics import (
    constraint_leakage_full, hermiticity_error, unitarity_error,
    principal_response_eigenvalue
)
from .scan import scan_control, branch_separation
from .fold import free_fold_fit
from .eth import eth_scaling
from .response import response_spectrum
from .sdi import run_sdi
from .io import write_csv, write_json

def _evaluate_for_sdi(cfg):
    model=build_model(cfg)
    scan,best,_=scan_control(model,cfg)
    # Exact algebra diagnostics in full Hilbert space.
    leakage=constraint_leakage_full(model.H0,model.gauss,model.physical_indices)
    idx=model.physical_indices
    Hd=restrict(model.H0,idx)
    herm=hermiticity_error(Hd)

    # Objective: find a real collective soft-response mode while heavily penalizing
    # actual constraint leakage or non-Hermiticity. No fold/ETH target is included.
    score=float(best["sigma_min"] + 1e6*np.max(leakage) + 1e6*herm)
    return score,{"best_scan":best,"epsilon_C":float(np.max(leakage)),
                  "hermiticity_error":herm,"metadata":model.metadata}

def run(cfg):
    out=Path(cfg["output_dir"]); out.mkdir(parents=True,exist_ok=True)

    best_cfg,sdi_diag,sdi_records=run_sdi(cfg,_evaluate_for_sdi)
    write_json(out/"best_config.json",best_cfg)
    write_json(out/"sdi_records.json",sdi_records)

    model=build_model(best_cfg)
    scan,best,caches=scan_control(model,best_cfg)
    write_csv(out/"scan.csv",scan)

    # Critical/pseudocritical exact response.
    gc=float(best["g"])
    H,E,V,chi,R,response_vals=caches[gc]
    vals,principal,smin=principal_response_eigenvalue(R)

    eig_rows=[{"index":i,"real":float(z.real),"imag":float(z.imag),
               "abs":float(abs(z))} for i,z in enumerate(vals)]
    write_csv(out/"critical_response_eigenvalues.csv",eig_rows)

    # Algebra audit is performed in full Hilbert space, not inferred.
    Hfull=model.H0+gc*model.H_control
    leakage=constraint_leakage_full(Hfull,model.gauss,model.physical_indices)
    Hphys=restrict(Hfull,model.physical_indices)
    herm=hermiticity_error(Hphys)
    unit=unitarity_error(Hphys)

    # Finite-size +/- source branches. Fit alpha freely on points on one side
    # of the pseudocritical minimum.
    gscan=np.array([r["g"] for r in scan])
    span=(gscan.max()-gscan.min())
    post=np.linspace(gc+0.01*span,gc+0.22*span,16)
    branches=branch_separation(model,best_cfg,post)
    write_csv(out/"branches.csv",branches)

    # Use smallest source for approximate h->0 finite-size branch separation.
    hmin=min(best_cfg["scan"]["source_fields"])
    bsel=[r for r in branches if np.isclose(r["source"],hmin)]
    fold=free_fold_fit([r["g"] for r in bsel],[r["branch_sep"] for r in bsel],
                       gc_guess=gc,
                       max_points=int(best_cfg["fold_fit"]["max_points"]),
                       min_distance=float(best_cfg["fold_fit"]["min_distance"]))

    # ETH/code-motion test in exact physical eigensystem at pseudocritical point.
    G=restrict(model.G_code,model.physical_indices)
    eth=eth_scaling(E,V,G,reference=best_cfg["eth"]["reference"],
                    window_fraction=float(best_cfg["eth"]["window_fraction"]),
                    min_matrix_element=float(best_cfg["eth"]["min_matrix_element"]))
    eth_rows=[]
    for row in eth.pop("rows"):
        eth_rows.append({"n":int(row[0]),"E_n":row[1],"omega":row[2],
                         "DeltaE_local":row[3],
                         "DeltaE_over_omega":row[4],"G2":row[5]})
    write_csv(out/"eth.csv",eth_rows)

    vcfg=best_cfg.get("verdict",{})
    fold_ok=bool(
        fold.get("success",False)
        and vcfg.get("fold_alpha_min",-np.inf) <= fold.get("alpha",np.nan) <= vcfg.get("fold_alpha_max",1e99)
        and fold.get("r2",-np.inf) >= vcfg.get("fold_r2_min",-np.inf)
    )
    eth_slope=eth.get("loglog_slope",np.nan)
    eth_r2=eth.get("loglog_r2",np.nan)
    eth_ok=bool(
        np.isfinite(eth_slope) and np.isfinite(eth_r2)
        and vcfg.get("eth_slope_min",-np.inf) <= eth_slope <= vcfg.get("eth_slope_max",np.inf)
        and eth_r2 >= vcfg.get("eth_r2_min",-np.inf)
    )
    verdict={
        "soft_mode":bool(smin <= vcfg.get("soft_sigma_max",np.inf)),
        "constraint_closure":bool(np.max(leakage) <= vcfg.get("constraint_leakage_max",np.inf)),
        "unitarity":bool(unit <= vcfg.get("unitarity_error_max",np.inf)),
        "fold_half_scaling":fold_ok,
        "eth_deltaE_over_omega_scaling":eth_ok,
    }
    verdict["all_requested_signatures"]=bool(all(verdict.values()))

    summary={
        "verdict":verdict,
        "interpretation":{
            "exact_response":True,
            "finite_size":True,
            "warning":"No result is pre-forced to alpha=0.5 or ETH proportionality."
        },
        "seed":int(best_cfg["seed"]),
        "model":model.metadata,
        "pseudocritical_g":gc,
        "R_principal":{"real":float(principal.real),"imag":float(principal.imag),
                       "abs":float(abs(principal))},
        "R_sigma_min":float(smin),
        "epsilon_C":float(np.max(leakage)),
        "constraint_leakage_by_generator":leakage,
        "hermiticity_error":float(herm),
        "unitarity_error":float(unit),
        "fold_fit":fold,
        "eth_fit":eth,
        "sdi":sdi_diag
    }
    write_json(out/"summary.json",summary)

    np.savez_compressed(
        out/"archive.npz",
        H_physical=Hphys,
        energies=E,
        eigenvectors=V,
        chi_bridge=chi,
        R_bridge=R,
        R_eigenvalues=vals,
        G_code=G,
        physical_indices=model.physical_indices,
        constraint_leakage=leakage,
        seed=np.array([int(best_cfg["seed"])],dtype=np.int64)
    )
    return summary
