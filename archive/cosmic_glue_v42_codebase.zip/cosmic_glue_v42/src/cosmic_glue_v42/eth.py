from __future__ import annotations
import numpy as np
from scipy.stats import linregress

def _local_spacing(E, n):
    if n == 0:
        return E[1]-E[0]
    if n == len(E)-1:
        return E[-1]-E[-2]
    return 0.5*((E[n]-E[n-1])+(E[n+1]-E[n]))

def eth_scaling(E, V, G, reference="microcanonical", window_fraction=0.35,
                min_matrix_element=1e-14):
    E = np.asarray(E); V=np.asarray(V); G=np.asarray(G)
    if reference == "ground":
        a = 0
    elif reference == "microcanonical":
        a = len(E)//2
    else:
        raise ValueError(reference)

    ga = V[:,a]
    rows=[]
    for n in range(len(E)):
        if n==a:
            continue
        w = abs(E[n]-E[a])
        if w <= 1e-13:
            continue
        elem = abs(np.vdot(ga, G @ V[:,n]))**2
        if elem < min_matrix_element:
            continue
        dE = max(_local_spacing(E,n), 1e-15)
        x = dE/w
        rows.append((n, E[n], w, dE, x, elem))

    arr=np.array(rows,float) if rows else np.empty((0,6))
    if len(arr)<4:
        return {"reference_index":a,"rows":arr,"loglog_slope":np.nan,
                "loglog_r2":np.nan,"linear_origin_coeff":np.nan}

    # Prefer a central frequency window to avoid UV/level-spacing endpoints.
    w=arr[:,2]
    lo=np.quantile(w,(1-window_fraction)/2)
    hi=np.quantile(w,1-(1-window_fraction)/2)
    sel=(w>=lo)&(w<=hi)
    x=arr[sel,4]; y=arr[sel,5]
    good=(x>0)&(y>0)
    lr=linregress(np.log(x[good]),np.log(y[good]))
    coeff=float(np.dot(x[good],y[good])/np.dot(x[good],x[good]))
    return {
        "reference_index":a,
        "rows":arr,
        "loglog_slope":float(lr.slope),
        "loglog_intercept":float(lr.intercept),
        "loglog_r2":float(lr.rvalue**2),
        "linear_origin_coeff":coeff,
        "fit_count":int(np.sum(good)),
    }
