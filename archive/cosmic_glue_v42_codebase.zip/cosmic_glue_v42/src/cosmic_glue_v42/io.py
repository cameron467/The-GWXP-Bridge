from __future__ import annotations
from pathlib import Path
import csv,json
import numpy as np

def write_csv(path, rows):
    path=Path(path)
    if not rows:
        path.write_text("")
        return
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def jsonable(x):
    if isinstance(x,(np.floating,np.integer)):
        return x.item()
    if isinstance(x,complex):
        return {"real":x.real,"imag":x.imag}
    if isinstance(x,np.ndarray):
        return x.tolist()
    if isinstance(x,dict):
        return {k:jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):
        return [jsonable(v) for v in x]
    return x

def write_json(path,obj):
    Path(path).write_text(json.dumps(jsonable(obj),indent=2),encoding="utf-8")
