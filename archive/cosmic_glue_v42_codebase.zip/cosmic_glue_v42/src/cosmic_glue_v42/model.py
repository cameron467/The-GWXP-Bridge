from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import scipy.sparse as sp
from .graph import edges as make_edges, nnn_edges
from .operators import (
    fermion_annihilation, number_op, link_op_x, link_op_z,
    parity_op, identity
)

@dataclass
class BuiltModel:
    H0: sp.csr_matrix
    H_control: sp.csr_matrix
    H_components: dict[str, sp.csr_matrix]
    gauss: list[sp.csr_matrix]
    bridge_ops: list[sp.csr_matrix]
    bridge_quadratures: list[sp.csr_matrix]
    response_ops: list[sp.csr_matrix]
    G_code: sp.csr_matrix
    physical_indices: np.ndarray
    metadata: dict

def build_model(cfg: dict) -> BuiltModel:
    gcfg = cfg["graph"]
    mcfg = cfg["model"]
    n = int(gcfg["n_sites"])
    eds = make_edges(gcfg["kind"], n)
    n_e = len(eds)

    # Qubit layout:
    # f_x = x; c_x = n+x; F-link = 2n+e; H-link = 2n+n_e+e.
    nfm = 2*n
    nq = 2*n + 2*n_e
    dim = 2**nq
    I = identity(nq)

    f = [fermion_annihilation(x, nfm, nq) for x in range(n)]
    c = [fermion_annihilation(n+x, nfm, nq) for x in range(n)]
    nf = [number_op(x, nfm, nq) for x in range(n)]
    nc = [number_op(n+x, nfm, nq) for x in range(n)]

    UF, UH, EF, EH = [], [], [], []
    for e in range(n_e):
        qf = 2*n + e
        qh = 2*n + n_e + e
        UF.append(link_op_x(qf, nq))
        UH.append(link_op_x(qh, nq))
        EF.append(link_op_z(qf, nq))
        EH.append(link_op_z(qh, nq))

    B = [(c[x].getH() @ f[x]).tocsr() for x in range(n)]
    BX = [(b + b.getH()).tocsr() for b in B]

    # Map incident links for Z2 Gauss generators.
    incident = [[] for _ in range(n)]
    for e, (x,y) in enumerate(eds):
        incident[x].append(e); incident[y].append(e)

    gauss = []
    for x in range(n):
        gf = parity_op(x, nq)
        gh = parity_op(n+x, nq)
        for e in incident[x]:
            gf = gf @ EF[e]
            gh = gh @ EH[e]
        gauss.extend([gf.tocsr(), gh.tocsr()])

    def z():
        return sp.csr_matrix((dim, dim), dtype=np.complex128)

    HF = z(); HH = z(); HB = z(); HEX = z(); HG = z(); Hlink = z(); Hocc = z()

    # Gauge-covariant rishon hopping.
    for e, (x,y) in enumerate(eds):
        tf = f[x].getH() @ UF[e] @ f[y]
        th = c[x].getH() @ UH[e] @ c[y]
        HF += -float(mcfg["t_f"]) * (tf + tf.getH())
        HH += -float(mcfg["t_h"]) * (th + th.getH())

    for x in range(n):
        HF += float(mcfg["m_f"]) * nf[x]
        HH += float(mcfg["m_h"]) * nc[x]
        bnb = B[x].getH() @ B[x]
        HB += float(mcfg["delta_b"]) * bnb
        # finite local repulsion; for spinless single B this is algebraically bounded
        HB += float(mcfg["u_b"]) * (bnb @ bnb)

        # Soft microscopic occupancy preference, not a hard constraint:
        # favors one rishon per abstract process vertex while retaining a
        # fully linear finite Hilbert space and allowing virtual empty/double states.
        qocc = nf[x] + nc[x] - I
        Hocc += float(mcfg.get("u_occupancy", 0.0)) * (qocc @ qocc)

    # Deterministic nonintegrable hidden-sector density interactions.
    for x,y in eds:
        HH += float(mcfg["j_h_nn"]) * (nc[x] @ nc[y])
    for x,y in nnn_edges(gcfg["kind"], n):
        # irrational deterministic coefficient breaks accidental integrability without RNG
        HH += float(mcfg["j_h_nnn"]) * np.sqrt(2.0 + x + 0.5*y) * (nc[x] @ nc[y])

    # Link electric energy.
    for e in range(n_e):
        Hlink += -float(mcfg["electric_f"]) * EF[e]
        Hlink += -float(mcfg["electric_h"]) * EH[e]

    # Literal covariant bifundamental exchange:
    # B_x^\dagger U_F B_y U_H^\dagger + h.c.
    # Its Hermitian bond quadrature is gauge invariant and is therefore the
    # physical bridge-response observable used after Gauss projection.
    response_ops = []
    exchange_terms = []
    for e, (x,y) in enumerate(eds):
        T = B[x].getH() @ UF[e] @ B[y] @ UH[e].getH()
        Xb = (T + T.getH()).tocsr()
        response_ops.append(Xb)
        exchange_terms.append(T)
        HEX += -float(mcfg["t_b"]) * Xb

    # Z2 Gauss penalty. Physical sector is G=+1.
    UG = float(mcfg["u_g"])
    for G in gauss:
        HG += UG * 0.5 * (I - G)

    # Global, geometry-free control parameter. It biases relative F/H rishon loading.
    Hcontrol = z()
    for x in range(n):
        Hcontrol += float(mcfg["loading_coupling"]) * (nc[x] - nf[x])

    H0 = (HF + HH + HB + HEX + HG + Hlink + Hocc).tocsr()

    # Candidate code-motion generator: a deterministic, gauge-invariant
    # weighted bridge quadrature.  Unequal irrational weights remove a spurious
    # reflection-selection rule in very small exact-diagonalization systems.
    Gcode = z()
    for e, Xb in enumerate(response_ops):
        Gcode += np.sqrt(2.0 + e) * Xb
    Gcode = 0.5 * (Gcode + Gcode.getH())

    # Physical computational-basis states are simultaneous +1 states of diagonal Gauss ops.
    # In this Z2 convention gauss contains Z/parity products and is diagonal.
    diag_ok = np.ones(dim, dtype=bool)
    for G in gauss:
        d = np.real_if_close(G.diagonal()).real
        diag_ok &= np.isclose(d, 1.0, atol=1e-12)
    phys = np.flatnonzero(diag_ok)

    return BuiltModel(
        H0=H0, H_control=Hcontrol.tocsr(),
        H_components={"H_F":HF.tocsr(),"H_H":HH.tocsr(),"H_B":HB.tocsr(),
                      "H_exch":HEX.tocsr(),"H_G":HG.tocsr(),"H_link":Hlink.tocsr(),
                      "H_occupancy":Hocc.tocsr()},
        gauss=gauss, bridge_ops=B, bridge_quadratures=BX,
        response_ops=response_ops,
        G_code=Gcode.tocsr(), physical_indices=phys,
        metadata={"n_sites":n,"edges":eds,"n_qubits":nq,"full_dim":dim,
                  "physical_dim":int(len(phys))}
    )

def restrict(A: sp.csr_matrix, idx: np.ndarray) -> np.ndarray:
    return A[idx][:, idx].toarray()
