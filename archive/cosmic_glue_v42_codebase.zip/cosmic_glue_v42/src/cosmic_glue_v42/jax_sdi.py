from __future__ import annotations
import numpy as np

def jax_static_objective(component_stack, theta, gauss_stack=None, physical_projector=None):
    """
    Differentiable structural helper for custom cluster workflows.
    `component_stack[p]` are dense Hermitian matrices and theta[p] their couplings.
    This function does not encode target physics; it returns Hermiticity/leakage
    diagnostics that can be combined with a user-defined response objective.
    """
    import jax
    jax.config.update("jax_enable_x64", True)
    import jax.numpy as jnp

    C=jnp.asarray(component_stack)
    t=jnp.asarray(theta)
    H=jnp.tensordot(t,C,axes=1)
    herm=jnp.linalg.norm(H-H.conj().T)

    leak=jnp.array(0.0)
    if gauss_stack is not None and physical_projector is not None:
        P=jnp.asarray(physical_projector)
        Q=jnp.eye(P.shape[0],dtype=P.dtype)-P
        for G in jnp.asarray(gauss_stack):
            comm=H@G-G@H
            leak=jnp.maximum(leak,jnp.linalg.norm(Q@comm@P,ord=2))
    return H,herm,leak
