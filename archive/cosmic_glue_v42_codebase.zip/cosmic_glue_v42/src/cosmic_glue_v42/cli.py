from __future__ import annotations
import argparse
from .config import Config
from .pipeline import run

def main(argv=None):
    p=argparse.ArgumentParser(prog="cosmic-glue-v42")
    sp=p.add_subparsers(dest="cmd",required=True)
    r=sp.add_parser("run")
    r.add_argument("--config",required=True)
    a=p.parse_args(argv)
    if a.cmd=="run":
        cfg=Config.load(a.config).raw
        summary=run(cfg)
        print("=== V4.2 RUN COMPLETE ===")
        print("pseudocritical g:",summary["pseudocritical_g"])
        print("R principal:",summary["R_principal"])
        print("R sigma_min:",summary["R_sigma_min"])
        print("epsilon_C:",summary["epsilon_C"])
        print("unitarity_error:",summary["unitarity_error"])
        print("fold_fit:",summary["fold_fit"])
        print("eth_fit:",summary["eth_fit"])
