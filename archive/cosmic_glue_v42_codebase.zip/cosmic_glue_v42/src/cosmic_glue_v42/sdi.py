from __future__ import annotations
import copy
import numpy as np

def run_sdi(base_cfg, evaluator):
    """
    Structure-driven inversion as a deterministic multi-start search around primitive
    couplings.  It DOES NOT include an alpha=0.5 or ETH target in the objective.

    evaluator(cfg) must return:
      score = soft-mode sigma_min + constraint/Hermiticity penalties
      diagnostics dictionary
    """
    s=base_cfg["sdi"]
    if not s.get("enabled",True):
        score,diag=evaluator(base_cfg)
        return base_cfg,diag,[{"score":score,"cfg":base_cfg}]

    rng=np.random.default_rng(int(base_cfg["seed"]))
    names=list(s["parameter_names"])
    scale=float(s["search_scale"])
    mult=int(s["multistarts"])
    steps=int(s["steps"])
    lr=float(s["learning_rate"])

    records=[]
    best_cfg=copy.deepcopy(base_cfg)
    best_score,best_diag=evaluator(best_cfg)
    records.append({"score":float(best_score),"params":{n:best_cfg["model"][n] for n in names}})

    # SPSA: two evaluations per step regardless of parameter count.
    # Good for expensive exact-diagonalization objectives.
    for start in range(mult):
        cfg=copy.deepcopy(base_cfg)
        theta=np.array([cfg["model"][n] for n in names],float)
        theta += scale*rng.normal(size=len(theta))
        for k in range(steps):
            ck=0.05/(k+1)**0.101
            ak=lr/(k+10)**0.602
            delta=rng.choice([-1.0,1.0],size=len(theta))

            vals=[]
            for sign in (+1,-1):
                trial=copy.deepcopy(cfg)
                t=theta+sign*ck*delta
                for i,n in enumerate(names):
                    trial["model"][n]=float(t[i])
                score,_=evaluator(trial)
                vals.append(score)
            grad=((vals[0]-vals[1])/(2*ck))*delta
            theta=theta-ak*grad

        for i,n in enumerate(names):
            cfg["model"][n]=float(theta[i])
        score,diag=evaluator(cfg)
        records.append({"score":float(score),"params":{n:cfg["model"][n] for n in names}})
        if score<best_score:
            best_score,best_cfg,best_diag=score,cfg,diag

    return best_cfg,best_diag,records
