from __future__ import annotations
import os
import numpy as np

def enable_jax_x64():
    import jax
    jax.config.update("jax_enable_x64", True)

def to_numpy(x):
    try:
        import cupy as cp
        if isinstance(x, cp.ndarray):
            return cp.asnumpy(x)
    except Exception:
        pass
    try:
        import jax
        return np.asarray(jax.device_get(x))
    except Exception:
        return np.asarray(x)

def get_xp(name: str):
    name = name.lower()
    if name == "jax":
        enable_jax_x64()
        import jax.numpy as jnp
        return jnp
    if name == "cupy":
        import cupy as cp
        return cp
    if name == "numpy":
        return np
    raise ValueError(f"Unknown backend {name!r}")
