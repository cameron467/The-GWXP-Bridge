from __future__ import annotations

def edges(kind: str, n: int):
    if n < 2:
        raise ValueError("n_sites must be >= 2")
    if kind == "chain":
        return [(i, i + 1) for i in range(n - 1)]
    if kind == "ring":
        if n < 3:
            raise ValueError("ring requires n_sites >= 3")
        return [(i, (i + 1) % n) for i in range(n)]
    raise ValueError(f"unsupported graph kind {kind!r}")

def nnn_edges(kind: str, n: int):
    if kind == "chain":
        return [(i, i + 2) for i in range(n - 2)]
    if kind == "ring":
        if n < 4:
            return []
        return sorted({tuple(sorted((i, (i+2) % n))) for i in range(n)})
    raise ValueError(kind)
