from __future__ import annotations
import numpy as np
import scipy.linalg as la

def diagonalize(H):
    E, V = la.eigh(np.asarray(H))
    return E, V

def retarded_bridge_susceptibility(E, V, ops, eta=1e-8, reference_index=0):
    """Zero-temperature / pure-eigenstate complete Lehmann response."""
    E=np.asarray(E); V=np.asarray(V)
    a=int(reference_index)
    va=V[:,a]
    m=len(ops)
    chi=np.zeros((m,m),complex)
    for n in range(len(E)):
        if n==a:
            continue
        gap=E[n]-E[a]
        left=np.array([np.vdot(va,O@V[:,n]) for O in ops],complex)
        right=np.array([np.vdot(V[:,n],O@va) for O in ops],complex)
        chi += np.outer(left,right)/(-gap+1j*eta)
        chi -= np.outer(right,left)/( gap+1j*eta)
    return chi

def thermal_retarded_susceptibility(E,V,ops,beta=1.0,eta=1e-8):
    """
    Exact finite-temperature Kubo response using the complete eigensystem:
      chi_ab(0)=sum_mn (p_m-p_n) O^a_mn O^b_nm /
                 (E_m-E_n+i eta).
    """
    E=np.asarray(E); V=np.asarray(V)
    shifted=E-E.min()
    w=np.exp(-float(beta)*shifted)
    p=w/w.sum()
    # Operators in energy basis.
    OE=[V.conj().T@np.asarray(O)@V for O in ops]
    m=len(ops)
    chi=np.zeros((m,m),complex)
    for i in range(len(E)):
        for j in range(len(E)):
            if i==j:
                continue
            den=(E[i]-E[j])+1j*eta
            pref=(p[i]-p[j])/den
            for a in range(m):
                oa=OE[a][i,j]
                if abs(oa)==0:
                    continue
                for b in range(m):
                    chi[a,b]+=pref*oa*OE[b][j,i]
    return chi

def inverse_response(chi,rcond=1e-10):
    return la.pinv(np.asarray(chi),rtol=float(rcond))

def response_spectrum(H,ops,eta=1e-8,rcond=1e-10,reference="ground",
                      reference_index=0,beta=1.0):
    E,V=diagonalize(H)
    if reference=="thermal":
        chi=thermal_retarded_susceptibility(E,V,ops,beta=beta,eta=eta)
    else:
        chi=retarded_bridge_susceptibility(E,V,ops,eta,reference_index)
    R=inverse_response(chi,rcond)
    return E,V,chi,R
