from __future__ import annotations
import numpy as np
import scipy.linalg as la
from .model import restrict
from .response import response_spectrum
from .diagnostics import principal_response_eigenvalue
from .accelerated import exact_thermal_response

def scan_control(model,cfg):
    scfg=cfg["scan"]; rcfg=cfg["response"]
    idx=model.physical_indices
    H0=restrict(model.H0,idx)
    Hc=restrict(model.H_control,idx)
    ops=[restrict(O,idx) for O in model.response_ops]

    gvals=np.linspace(float(scfg["g_min"]),float(scfg["g_max"]),int(scfg["points"]))
    rows=[]; caches={}
    for g in gvals:
        H=H0+g*Hc
        if rcfg.get("reference","ground")=="thermal":
            E,V,chi,R,vals=exact_thermal_response(
                H,ops,beta=float(rcfg.get("beta",1.0)),
                eta=float(rcfg["eta"]),rcond=float(rcfg["pinv_rcond"]),
                backend=cfg.get("backend","jax")
            )
        else:
            E,V,chi,R=response_spectrum(
                H,ops,eta=float(rcfg["eta"]),rcond=float(rcfg["pinv_rcond"]),
                reference=rcfg.get("reference","ground"),
                beta=float(rcfg.get("beta",1.0)),reference_index=0
            )
            vals=np.linalg.eigvals(R)
        _,principal,smin=principal_response_eigenvalue(R)
        rows.append({
            "g":float(g),
            "principal_real":float(principal.real),
            "principal_imag":float(principal.imag),
            "principal_abs":float(abs(principal)),
            "sigma_min":float(smin),
            "gap":float(E[1]-E[0]) if len(E)>1 else np.nan
        })
        caches[float(g)]=(H,E,V,chi,R,vals)
    best=min(rows,key=lambda r:r["sigma_min"])
    return rows,best,caches

def _thermal_expectation(H,O,beta):
    E,V=la.eigh(H)
    p=np.exp(-beta*(E-E.min())); p=p/p.sum()
    Oe=V.conj().T@O@V
    return float(np.sum(p*np.real(np.diag(Oe))))

def branch_separation(model,cfg,g_values):
    """
    Finite-size +/- source branches from thermal expectation values.
    alpha is fitted later with no 1/2 prior.
    """
    idx=model.physical_indices
    H0=restrict(model.H0,idx)
    Hc=restrict(model.H_control,idx)
    O=sum(restrict(B,idx) for B in model.response_ops)
    beta=float(cfg["scan"].get("branch_beta",cfg["response"].get("beta",1.0)))
    out=[]
    for h in cfg["scan"]["source_fields"]:
        for g in g_values:
            vals=[]
            for sgn in (-1,+1):
                H=H0+g*Hc-sgn*float(h)*O
                vals.append(_thermal_expectation(H,O,beta))
            out.append({"source":float(h),"g":float(g),
                        "m_minus":vals[0],"m_plus":vals[1],
                        "branch_sep":float(abs(vals[1]-vals[0]))})
    return out
