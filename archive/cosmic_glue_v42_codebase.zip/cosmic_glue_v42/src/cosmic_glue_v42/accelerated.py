from __future__ import annotations
import numpy as np

def _thermal_kernel_numpy(E,beta,eta):
    E=np.asarray(E)
    p=np.exp(-beta*(E-E.min())); p=p/p.sum()
    d=E[:,None]-E[None,:]
    K=(p[:,None]-p[None,:])/(d+1j*eta)
    np.fill_diagonal(K,0.0)
    return K

def exact_thermal_response(H,ops,beta=1.0,eta=1e-8,rcond=1e-10,backend="jax"):
    """
    Full-spectrum exact finite-system thermal Kubo response.
    JAX and CuPy paths keep the dense eigensystem and contractions on accelerator.
    Returns NumPy arrays for archival/diagnostics.
    """
    backend=backend.lower()

    if backend=="jax":
        import jax
        jax.config.update("jax_enable_x64",True)
        import jax.numpy as xp
        Hx=xp.asarray(H)
        Ox=xp.stack([xp.asarray(O) for O in ops],axis=0)
        E,V=xp.linalg.eigh(Hx)
        p=xp.exp(-beta*(E-xp.min(E))); p=p/xp.sum(p)
        d=E[:,None]-E[None,:]
        K=(p[:,None]-p[None,:])/(d+1j*eta)
        K=K.at[xp.diag_indices(E.shape[0])].set(0.0)
        Oe=xp.einsum("ki,akl,lj->aij",xp.conj(V),Ox,V)
        chi=xp.einsum("ij,aij,bji->ab",K,Oe,Oe)
        R=xp.linalg.pinv(chi,rtol=rcond)
        vals=xp.linalg.eigvals(R)
        return tuple(np.asarray(jax.device_get(x)) for x in (E,V,chi,R,vals))

    if backend=="cupy":
        import cupy as xp
        Hx=xp.asarray(H)
        Ox=xp.stack([xp.asarray(O) for O in ops],axis=0)
        E,V=xp.linalg.eigh(Hx)
        p=xp.exp(-beta*(E-xp.min(E))); p=p/xp.sum(p)
        d=E[:,None]-E[None,:]
        K=(p[:,None]-p[None,:])/(d+1j*eta)
        K[xp.diag_indices(E.shape[0])]=0.0
        Oe=xp.einsum("ki,akl,lj->aij",xp.conj(V),Ox,V)
        chi=xp.einsum("ij,aij,bji->ab",K,Oe,Oe)
        R=xp.linalg.pinv(chi,rcond=rcond)
        vals=xp.linalg.eigvals(R)
        return tuple(xp.asnumpy(x) for x in (E,V,chi,R,vals))

    if backend=="numpy":
        import scipy.linalg as la
        Hx=np.asarray(H)
        E,V=la.eigh(Hx)
        K=_thermal_kernel_numpy(E,beta,eta)
        Oe=np.stack([V.conj().T@np.asarray(O)@V for O in ops],axis=0)
        chi=np.einsum("ij,aij,bji->ab",K,Oe,Oe)
        R=la.pinv(chi,rtol=rcond)
        vals=la.eigvals(R)
        return E,V,chi,R,vals

    raise ValueError(f"Unsupported exact dense backend: {backend}")
