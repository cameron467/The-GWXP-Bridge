from __future__ import annotations
import numpy as np
import scipy.sparse as sp

I2 = sp.identity(2, dtype=np.complex128, format="csr")
X2 = sp.csr_matrix(np.array([[0,1],[1,0]], complex))
Y2 = sp.csr_matrix(np.array([[0,-1j],[1j,0]], complex))
Z2 = sp.csr_matrix(np.array([[1,0],[0,-1]], complex))
SP = sp.csr_matrix(np.array([[0,1],[0,0]], complex))  # |0><1| annihilation
SM = SP.getH()

def kron_all(ops):
    out = sp.csr_matrix([[1.0+0j]])
    for op in ops:
        out = sp.kron(out, op, format="csr")
    return out

def one_qubit(op, q: int, nq: int):
    ops = [I2] * nq
    ops[q] = op
    return kron_all(ops)

def fermion_annihilation(mode: int, n_fermion_modes: int, nq_total: int):
    # Jordan-Wigner order is the first n_fermion_modes qubits.
    ops = []
    for q in range(nq_total):
        if q < mode:
            ops.append(Z2)
        elif q == mode:
            ops.append(SP)
        else:
            ops.append(I2)
    return kron_all(ops)

def fermion_creation(mode: int, n_fermion_modes: int, nq_total: int):
    return fermion_annihilation(mode, n_fermion_modes, nq_total).getH()

def number_op(mode: int, n_fermion_modes: int, nq_total: int):
    a = fermion_annihilation(mode, n_fermion_modes, nq_total)
    return (a.getH() @ a).tocsr()

def parity_op(mode: int, nq_total: int):
    return one_qubit(Z2, mode, nq_total)

def link_op_x(q: int, nq_total: int):
    return one_qubit(X2, q, nq_total)

def link_op_z(q: int, nq_total: int):
    return one_qubit(Z2, q, nq_total)

def identity(nq_total: int):
    return sp.identity(2**nq_total, dtype=np.complex128, format="csr")
