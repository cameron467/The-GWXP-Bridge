from __future__ import annotations
import numpy as np
from scipy.optimize import curve_fit

def free_fold_fit(g, branch_sep, gc_guess=None, max_points=12, min_distance=1e-5):
    """
    Fits Delta m = A * max(g-gc,0)^alpha with A,gc,alpha all free.
    No alpha=1/2 prior is imposed.
    """
    g=np.asarray(g,float); y=np.asarray(branch_sep,float)
    good=np.isfinite(g)&np.isfinite(y)&(y>0)
    g=g[good]; y=y[good]
    if len(g)<5:
        return {"success":False,"reason":"insufficient positive branch points"}

    order=np.argsort(g)
    g=g[order]; y=y[order]
    if len(g)>max_points:
        g=g[:max_points]; y=y[:max_points]

    if gc_guess is None:
        gc_guess=float(g.min()-0.05*(g.max()-g.min()+1e-12))

    def f(x,A,gc,alpha):
        return A*np.maximum(x-gc,1e-15)**alpha

    p0=[max(y.max(),1e-8),gc_guess,0.6]
    bounds=([0.0,g.min()-2*abs(np.ptp(g)+1e-9),0.05],
            [np.inf,g.min()-min_distance,2.5])
    try:
        popt,pcov=curve_fit(f,g,y,p0=p0,bounds=bounds,maxfev=30000)
        perr=np.sqrt(np.diag(pcov))
        pred=f(g,*popt)
        ss_res=float(np.sum((y-pred)**2))
        ss_tot=float(np.sum((y-y.mean())**2))
        r2=1-ss_res/ss_tot if ss_tot>0 else np.nan
        return {"success":True,"A":float(popt[0]),"gc":float(popt[1]),
                "alpha":float(popt[2]),"A_se":float(perr[0]),
                "gc_se":float(perr[1]),"alpha_se":float(perr[2]),
                "r2":float(r2),"n":int(len(g))}
    except Exception as exc:
        return {"success":False,"reason":repr(exc)}
