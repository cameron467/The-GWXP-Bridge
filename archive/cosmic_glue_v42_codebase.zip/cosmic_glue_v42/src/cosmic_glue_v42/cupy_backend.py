from __future__ import annotations

def lowest_hermitian_eigs(A_scipy_csr, k=16, which="SA", tol=1e-10):
    """
    GPU sparse Hermitian eigensolver.  This is used for large-system low-energy
    work only; a truncated Lehmann response must never be labeled exact.
    """
    import cupy as cp
    import cupyx.scipy.sparse as csp
    import cupyx.scipy.sparse.linalg as csl

    A=csp.csr_matrix(A_scipy_csr)
    w,v=csl.eigsh(A,k=k,which=which,tol=tol)
    order=cp.argsort(w)
    return cp.asnumpy(w[order]), cp.asnumpy(v[:,order])

def dense_exact_eigh(A_numpy):
    import cupy as cp
    A=cp.asarray(A_numpy)
    w,v=cp.linalg.eigh(A)
    return cp.asnumpy(w),cp.asnumpy(v)

def dense_response_eigvals(R_numpy):
    import cupy as cp
    vals=cp.linalg.eigvals(cp.asarray(R_numpy))
    return cp.asnumpy(vals)
