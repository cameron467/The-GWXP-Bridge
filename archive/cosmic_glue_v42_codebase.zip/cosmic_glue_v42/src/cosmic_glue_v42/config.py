from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(frozen=True)
class Config:
    raw: dict

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        with open(path, "r", encoding="utf-8") as f:
            return cls(json.load(f))

    @property
    def seed(self) -> int:
        return int(self.raw["seed"])

    @property
    def output_dir(self) -> Path:
        return Path(self.raw["output_dir"])
