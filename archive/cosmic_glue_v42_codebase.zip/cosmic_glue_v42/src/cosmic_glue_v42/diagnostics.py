from __future__ import annotations
import numpy as np
import scipy.linalg as la
import scipy.sparse as sp

def opnorm_dense(A):
    return float(la.svdvals(np.asarray(A))[0]) if A.size else 0.0

def hermiticity_error(H):
    H = np.asarray(H)
    return opnorm_dense(H - H.conj().T)

def unitarity_error(H, dt=0.173):
    H = np.asarray(H)
    U = la.expm(-1j*dt*H)
    I = np.eye(H.shape[0], dtype=complex)
    return opnorm_dense(U.conj().T @ U - I)

def constraint_leakage_full(H, gauss, physical_indices):
    """
    epsilon_C = max ||(I-P)[H,G_A]P||_2 in the full finite Hilbert space.
    Uses sparse operations and dense SVD only on the rectangular leakage block.
    """
    dim = H.shape[0]
    mask = np.zeros(dim, dtype=bool)
    mask[np.asarray(physical_indices)] = True
    qidx = np.flatnonzero(~mask)
    pidx = np.flatnonzero(mask)
    vals = []
    for G in gauss:
        C = (H @ G - G @ H).tocsr()
        block = C[qidx][:, pidx].toarray()
        vals.append(opnorm_dense(block))
    return np.asarray(vals, float)

def principal_response_eigenvalue(R):
    vals = la.eigvals(np.asarray(R))
    # For a generic retarded kernel, use the eigenvalue nearest the origin and
    # separately report sigma_min.  Do not silently force it real.
    k = int(np.argmin(np.abs(vals)))
    smin = float(la.svdvals(np.asarray(R))[-1])
    return vals, vals[k], smin
