# Cosmic Glue V4.2 finite-rishon numerical pipeline

This package is an executable **falsification/search pipeline** for the proposed V4.2 microscopic bridge.
It does **not** assume that the bridge has been derived from first principles.

The primitive Hamiltonian is a finite-dimensional Z2 quantum-link/rishon model on an abstract graph,

\[
H_{\rm micro}=H_F+H_H+H_B+H_{\rm exch}+U_G\sum_x (1-G_x)/2 ,
\]

with two spinless rishon species `f,c` at each vertex, finite Z2 link spins, and the composite bridge
\(B_x=c_x^\dagger f_x\).  The covariant exchange term is implemented literally as

\[
-t_B\sum_{\langle xy\rangle}
[B_x^\dagger U^F_{xy} B_y U^{H\dagger}_{xy}+{\rm h.c.}] .
\]

All microscopic terms are finite matrices.  Gauge/Gauss constraints are explicit matrices and are audited
from commutators; no boolean "success" flags exist.

## What the code measures

1. Exact finite-system retarded bridge susceptibility in `exact` mode and the inverse response
   \(R_B^R(0)=\chi_B^R(0)^{-1}\).  It reports **all** response eigenvalues and the smallest singular value.
2. A control-parameter scan locating the collective soft-response minimum.
3. A free nonlinear fit of branch separation
   \(\Delta m=A(g-g_c)^\alpha\).  `alpha` is never fixed to 0.5.
4. Off-diagonal code-motion-generator matrix elements.  It tests
   \(|G_{an}|^2 \propto \Delta E_n/|E_n-E_a|\) by regression and reports the fitted exponent/R².
5. Hermiticity, unitary-evolution error, and real constraint leakage
   \(\epsilon_C=\max_A\|(I-P)[H,G_A]P\|_2\).
6. A Kubo static-response / unitary-orbit diagnostic if requested.

## Important interpretation

A finite system has no exact thermodynamic singularity; the code locates a finite-size pseudocritical soft
mode.  A recovered exponent near 1/2 is evidence for fold-like behavior **in that model/size window**, not a
proof of GR or quantum gravity.

`exact` mode uses the complete physical-sector eigensystem.  `cupy_sparse` mode is for larger graphs; its
Lehmann response is truncated and output metadata explicitly says so.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
# for NVIDIA CUDA:
pip install -e '.[cuda]'

cosmic-glue-v42 run --config configs/default.json
```

Outputs are written under the configured output directory:
`scan.csv`, `critical_response_eigenvalues.csv`, `eth.csv`, `summary.json`, and `archive.npz`.

## GPU notes

Current CuPy exposes GPU sparse Hermitian `eigsh`; the large-system path uses it for low-energy states.
The full non-Hermitian response spectrum is only called "exact" when the complete physical-sector
eigensystem is formed.

## Scaling warning

The exact Fock/link Hilbert space grows exponentially.  Default `N=3` is deliberately small and auditable.
Increase `N` only in sparse mode or after adding tensor-network / distributed Krylov machinery.

## Gauge-invariant bridge response

The bare local composite `B_x=c_x^dagger f_x` is gauge covariant and therefore vanishes
when naively projected as an observable into the exact Gauss-law sector.  The numerical
response kernel is consequently built from the physical covariant bond operators
`B_x^dagger U_F B_y U_H^dagger + h.c.`.  This is deliberate, not a gauge-fixing shortcut.

## Rishon filling

The default run includes a finite onsite energetic term
`U_occ (n_f+n_c-1)^2`.  It is **not** projected as a hard constraint; it simply
makes the one-rishon-per-process sector dynamically relevant so the composite bridge
has nontrivial spectral weight.  Virtual empty/double states remain in the Hilbert space.

## Thermal exact response

The default instability search uses the complete finite-temperature Kubo/Lehmann sum
(`response.reference = "thermal"`).  This is intentional: the chaotic/ETH horizon sector
is a populated many-body sector, whereas the tiny default model's exact vacuum is often
rishon-polarized and has zero bridge spectral weight.  Because the complete physical
spectrum is used in `exact` mode, the thermal response is still an exact finite-system
quantity.

## Accelerator execution

For the default exact thermal response, `backend: "jax"` sends the full physical-sector
Hermitian eigendecomposition and vectorized Kubo contraction through JAX/XLA.  Set
`backend: "cupy"` to use CuPy/cuSOLVER instead.  The Hamiltonian/operator assembly remains
sparse on CPU because it is a one-time symbolic construction; repeated spectral work is
accelerated.  The post-hoc verdict thresholds are **not** part of the SDI objective.
