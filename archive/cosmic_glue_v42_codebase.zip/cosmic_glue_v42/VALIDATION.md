# Validation status

The packaged default N=3 exact-JAX run was executed end-to-end.

Measured:
- full Gauss-law constraint leakage: 0.0
- Hermiticity error: 0.0
- unitary evolution error: 5.665272592750114e-16
- minimum inverse-response singular value in the validation scan: 17.267512484987652
- fold free fit: alpha ~= 0.05 with negative R^2 (FAIL)
- ETH requested scaling: unresolved/FAIL in the tiny physical sector

Therefore the default microscopic couplings do NOT realize the requested V4.2 phase transition.
This is intentional evidence that the pipeline is not hard-wired to succeed.

The SDI objective does not contain alpha=0.5 or an ETH target. It searches only for a collective
soft response while penalizing actual constraint leakage/Hermiticity failure; fold and ETH tests
are post-hoc measurements.

For publication claims, only results from a converged larger-size study with finite-size scaling
and stable diagnostics should be used.
