import json
import numpy as np
from pathlib import Path
from cosmic_glue_v42.model import build_model, restrict
from cosmic_glue_v42.diagnostics import constraint_leakage_full, hermiticity_error

def load_cfg():
    p=Path(__file__).parents[1]/"configs"/"default.json"
    return json.loads(p.read_text())

def test_model_is_hermitian_and_gauge_closed():
    cfg=load_cfg()
    cfg["graph"]={"kind":"chain","n_sites":2}
    cfg["sdi"]["enabled"]=False
    m=build_model(cfg)
    H=restrict(m.H0,m.physical_indices)
    assert hermiticity_error(H)<1e-10
    leak=constraint_leakage_full(m.H0,m.gauss,m.physical_indices)
    assert np.max(leak)<1e-10
