#!/bin/bash
#SBATCH --job-name=cg-v42
#SBATCH --nodes=1
#SBATCH --gpus=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=128G
#SBATCH --time=24:00:00
#SBATCH --output=cg-v42-%j.out

set -euo pipefail
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export JAX_ENABLE_X64=True

source .venv/bin/activate
cosmic-glue-v42 run --config configs/default.json
