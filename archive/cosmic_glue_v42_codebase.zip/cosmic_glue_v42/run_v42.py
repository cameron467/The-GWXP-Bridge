from cosmic_glue_v42.config import Config
from cosmic_glue_v42.pipeline import run

if __name__=="__main__":
    cfg=Config.load("configs/default.json").raw
    run(cfg)
